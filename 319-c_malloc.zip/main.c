#include <stdio.h>
#include <stdlib.h>

int main(void) {
  int* ptr;
  ptr=(int*) malloc(3 * sizeof(int));
  *ptr=30000;
  *(ptr+1)=10;
  *(ptr+2)=100;

  printf("Primo intero = %d\n", *ptr);
  printf("Secondo intero = %d\n", *(ptr+1));
  printf("Terzo intero = %d\n\n", *(ptr+2));

  for (int i=0; i<3; i++){
    printf("Intero #%d = %d\n", i+1, *(ptr+i));
  }

  printf("\n\nIntero #2 = %d\n", ptr[1]);

  free(ptr);

  return 0;
}