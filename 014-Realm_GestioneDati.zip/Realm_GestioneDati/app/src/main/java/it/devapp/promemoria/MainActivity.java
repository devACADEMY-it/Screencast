package it.devapp.promemoria;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

import io.realm.OrderedRealmCollection;
import io.realm.Realm;
import io.realm.RealmChangeListener;
import io.realm.RealmCollection;
import io.realm.RealmConfiguration;
import io.realm.RealmResults;
import io.realm.Sort;

    public class MainActivity extends AppCompatActivity {

        private ListView lista;
        private final static String REALM_NAME="my_todo";
        private Realm realm;
        private PromemoriaAdapter adapter;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            realm=Realm.getInstance(new RealmConfiguration.Builder()
            .name(REALM_NAME)
            .build());

            RealmResults<Promemoria> list=realm.where(Promemoria.class).findAllSorted("testo", Sort.ASCENDING);
            adapter=new PromemoriaAdapter(this, list);
            lista= (ListView) findViewById(R.id.lista);
            lista.setAdapter(adapter);

            lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    final Promemoria p=adapter.getItem(i);

                    final AlertDialog dialog=new AlertDialog.Builder(MainActivity.this)
                            .setView(R.layout.dialog_layout)
                            .show();

                    ((Button)dialog.findViewById(R.id.btn_cancella))
                            .setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    realm.executeTransaction(new Realm.Transaction() {
                                        @Override
                                        public void execute(Realm realm) {
                                            p.deleteFromRealm();
                                            dialog.dismiss();
                                        }
                                    });
                                }
                            });

                    ((Button)dialog.findViewById(R.id.btn_modifica))
                            .setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    realm.executeTransaction(new Realm.Transaction() {
                                        @Override
                                        public void execute(Realm realm) {
                                            String t= ((EditText) dialog.findViewById(R.id.testonuovo))
                                                    .getText().toString();

                                            if (t.length()>0)
                                            {
                                                p.setTesto(t);
                                            }

                                            dialog.dismiss();
                                        }
                                    });
                                }
                            });
                }
            });



        }

        public void nuovaAttivita(View v)
        {
            EditText t= (EditText) findViewById(R.id.todo);
            final String s=t.getText().toString();
            if (s.length()==0)
                return;

            realm.executeTransaction(new Realm.Transaction()
            {
                @Override
                public void execute(Realm realm) {
                    Promemoria p=realm.createObject(Promemoria.class);
                    p.setTesto(s);
                }
            });

            t.getEditableText().clear();
        }

        @Override
        protected void onDestroy() {
            super.onDestroy();
            realm.close();
        }
    }
