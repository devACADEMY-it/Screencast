package it.devapp.promemoria;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.TextView;

import io.realm.OrderedRealmCollection;
import io.realm.RealmBaseAdapter;

public class PromemoriaAdapter extends RealmBaseAdapter<Promemoria> implements ListAdapter{

    private static class ViewHolder
    {
        TextView txt_title;
    }

    public PromemoriaAdapter(@NonNull Context context, @Nullable OrderedRealmCollection<Promemoria> data) {
        super(context, data);
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder vh;
        if (view==null)
        {
            view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.promemoria_layout, null);
            vh=new ViewHolder();
            vh.txt_title= (TextView) view.findViewById(R.id.text);
            view.setTag(vh);
        }
        else
            vh= (ViewHolder) view.getTag();

        Promemoria p=getItem(i);

        vh.txt_title.setText(p.getTesto());

        return view;
    }
}
