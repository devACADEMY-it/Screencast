package it.devapp.promemoria;

import io.realm.RealmObject;

public class Promemoria extends RealmObject {

    private String testo;

    public String getTesto() {
        return testo;
    }

    public void setTesto(String testo) {
        this.testo = testo;
    }

    @Override
    public String toString() {
        return testo;
    }
}
