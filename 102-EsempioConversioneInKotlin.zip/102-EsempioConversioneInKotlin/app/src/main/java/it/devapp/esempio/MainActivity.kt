/*
 * Screencast 
 * Android: iniziare a programmare in Kotlin
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.esempio

import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.view.View
import android.widget.EditText


class MainActivity : AppCompatActivity() {

    private var et: EditText? = null
    private var saluto: Saluto? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        et = findViewById(R.id.nome)

        saluto = Saluto("Un saluto a ")
    }

    fun saluta(v: View) {
        val ed = et!!.editableText
        if (ed.isNotEmpty()) {
            AlertDialog.Builder(this)
                    .setTitle("Saluto...")
                    .setMessage(saluto!!.toString() + ed)
                    .setPositiveButton("Chiudi", null)
                    .show()
        }
        ed.clear()
    }
}
