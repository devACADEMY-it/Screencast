/*
 * Screencast 
 * Android: iniziare a programmare in Kotlin
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.esempio

class Saluto(var messaggio: String) {

    override fun toString(): String {
        return messaggio
    }
}