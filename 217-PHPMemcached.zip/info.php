<?php
  phpinfo()
?>
