<?php
  if (array_key_exists("pulsante_clickato", $_POST)){
      $memcached=new Memcached();
      $memcached->addServer("127.0.0.1", 11211);
      $valore=$memcached->get("conta_click");
      if ($valore){ 
         $valore++;
         echo "Siamo arrivati a ".$valore." click!";
         $memcached->set("conta_click", $valore);
      }
      else{
         echo "Siamo al primo click!";
         $memcached->set("conta_click", 1);
      }
  }
?>
<form method="POST">
<input type="submit" name="pulsante_clickato" value="Cliccami!"/>
</form>
