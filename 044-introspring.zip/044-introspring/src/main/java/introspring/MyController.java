/*
 * Screencast
 * Introduzione allo Spring Framework
 *
 * Disponibile su devACADEMY.it
 */

package introspring;

import java.time.LocalTime;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {

	@RequestMapping("/")
	public String home(Model model)
	{
		model.addAttribute("saluto", "Messaggio dal Model");
		return "home";
	}

	@RequestMapping("/ora")
	public String orario(Model model)
	{
		LocalTime lt=LocalTime.now();
		model.addAttribute("saluto", lt);
		return "home";
	}

}
