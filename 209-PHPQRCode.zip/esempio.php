<?php
require_once('vendor\autoload.php');
use Endroid\QrCode\Qrcode;

$qrCode=new QrCode('Questo è il messaggio da leggere');
$qrCode->setSize(200);
$qrCode->setMargin(5);
$qrCode->setLabel('Messaggio in QR', 12);
$qrCode->setForegroundColor(['r'=>0,'g'=>150,'b'=>0]);
//$qrCode->setBackgroundColor(['r'=>150,'g'=>0,'b'=>0]);
//$qrCode->setLogoPath('logo.png');
//$qrCode->setLogoWidth(150);
header('Content-Type:'.$qrCode->getContentType());
echo $qrCode->writeString();
$qrCode->writeFile(__DIR__.'/qrcode.png');
?>