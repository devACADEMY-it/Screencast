import os
print(f'Questo il valore che abbiamo importato: {os.environ["MESSAGGIO"]}')
