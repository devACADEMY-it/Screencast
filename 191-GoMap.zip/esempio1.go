package main
import "fmt"

func main(){
	pagella := make(map[string]int)
	pagella["Italiano"]=7
	pagella["Storia"]=6
	pagella["Matematica"]=8
	pagella["Geografia"]=8
	
	fmt.Printf("La pagella contiene %d materie", len(pagella))
	
}