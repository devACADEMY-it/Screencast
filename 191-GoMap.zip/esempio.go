package main
import "fmt"

type operaio struct{
	nome string
	cognome string
}

func main(){
	produzione := make(map[string]operaio)
	produzione["115599"]=operaio{
		"Alessio", "Belli"}
	produzione["115785"]=operaio{
		"Simone", "Rizzo"}
	produzione["297805"]=operaio{
		"Matteo", "Zeni"}
		
	op := produzione["115785"]
	fmt.Println(op.cognome)
	
	op = produzione["297805"]
	fmt.Println(op.nome)
}