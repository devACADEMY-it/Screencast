<?php
require_once('vendor/autoload.php');
use Webmozart\Assert\Assert;

function sommaNumeri($op1, $op2){
	Assert::numeric($op1, 'Gli argomenti devono essere numeri');
	Assert::numeric($op2, 'Gli argomenti devono essere numeri');
	return $op1+$op2;
}

function valutaPersona($arr){
	Assert::keyExists($arr, "cognome", $message="Non contiene il cognome");
	echo "Il cognome è ".$arr['cognome']."\n";
	Assert::greaterThan($arr['eta'], 0, "Indicata età minore di zero\n");
}

//echo sommaNumeri(3,4);
try { 
	//echo sommaNumeri(3, 'gatto');
	//echo sommaNumeri(3, 5);
	$arr=array();
	$arr['nome']="Alessio";
	$arr['cognome']="Rossi";
	$arr['eta']=27;
	valutaPersona($arr);
	echo "FINE TRY\n";
}
catch(exception $e){
	echo $e;
	echo "Restituito un errore\n";
}
echo "FINE PROGRAMMA"
?>