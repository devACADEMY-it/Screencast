#
# Screencast
# Telegram: realizzare un Bot in Python
#
# Disponibile su devACADEMY.it
#

from token_file import TOKEN
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
from random import choice

proverbi=None

def proverbio_random():
   return choice(proverbi)

def carica_lista(nome_file):
   global proverbi
   proverbi=[]
   with open(nome_file) as f:
      for p in f.readlines():
         proverbi.append(p.strip())

def echo(update, context):
   update.message.reply_text(update.message.text)

def quanti_proverbi(update, context):
   update.message.reply_text(len(proverbi))

def proverbio(update, context):
   update.message.reply_text(proverbio_random())

def main():
   carica_lista("proverbi.txt")

   updater= Updater(TOKEN, use_context=True)
   dp=updater.dispatcher

   dp.add_handler(MessageHandler(Filters.text, echo))
   dp.add_handler(CommandHandler("quanti", quanti_proverbi))
   dp.add_handler(CommandHandler("proverbio", proverbio))

   updater.start_polling()

   updater.idle()

if __name__=='__main__':
   main()