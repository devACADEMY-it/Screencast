#inserire in questa stringa il codice ottenuto dal BotFather
TOKEN="inserire token qui"