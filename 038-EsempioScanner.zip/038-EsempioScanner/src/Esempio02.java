/*
 * Screencast
 * Java: gestire gli input utente con la classe Scanner
 *
 * Disponibile su devACADEMY.it
 */

import java.util.Scanner;

public class Esempio02 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Immettere numeri interi da sommare...");

		int totale=0;

		while(s.hasNextInt())
		{
			totale+=s.nextInt();
			System.out.println("totale parziale .... "+totale);
		}

		System.out.println("Totale finale =   "+totale);

		s.close();
	}


}