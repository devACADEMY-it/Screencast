/*
 * Screencast
 * Java: gestire gli input utente con la classe Scanner
 *
 * Disponibile su devACADEMY.it
 */

import java.util.Scanner;

public class Esempio01 {

	public static void main(String[] args) {

		System.out.println("Come ti chiami?");

		Scanner s=new Scanner(System.in);

		String risposta=s.next();
		System.out.println("Ciao "+risposta);

		s.close();

	}

}