/*
 * Screencast
 * Java: gestire gli input utente con la classe Scanner
 *
 * Disponibile su devACADEMY.it
 */

import java.util.InputMismatchException;
import java.util.Scanner;

public class Esempio03 {

	public static void main(String[] args) {

		Scanner s=new Scanner(System.in);
		System.out.println("Inserire nome allievo e voto separati da spazio...");

		String nome=null;
		int voto=0;

		while(s.hasNext())
		{
			try
			{
				nome=s.next();
				voto=s.nextInt();

				System.out.println("Allievo : "+nome);
				System.out.println("Voto : "+voto);
			}
			catch(InputMismatchException i)
			{
				System.out.println("...input non valido...");
				s.next();
			}
		}

		System.out.println("\nFine");
		s.close();

	}
}