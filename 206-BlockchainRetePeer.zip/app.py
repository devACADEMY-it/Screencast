from flask import Flask, request
from blockchain import BlockchainSemplice, Blocco
import json
import requests
nodi=set()


app=Flask(__name__)
blockchain=BlockchainSemplice()

@app.route('/nuova', methods=['POST'])
def nuova():
   dati=request.get_json()
   blockchain.nuova_transazione(dati)
   return "OK", 200

@app.route('/blockchain', methods=['GET'])
def download_blockchain():
   dati=[blocco.__dict__ for blocco in blockchain.blockchain]
   return json.dumps({"blockchain":dati})

@app.route('/mine', methods=['GET'])
def mine():
   blockchain.crea_blocco()
   for n in nodi:
     r=requests.post(f"http://127.0.0.1:{n}/receive_block", json=json.dumps(blockchain.blockchain[-1].__dict__))
   return "OK", 200

@app.route('/receive_block', methods=['POST'])
def receive():
   dati=json.loads(request.get_json())
   nuovo=Blocco(id=dati['id'], transazioni=dati['transazioni'], hash_blocco_prec=dati['hash_blocco_prec'])
   nuovo.hash=dati['hash']
   nuovo.timestamp=dati['timestamp']
   blockchain.blockchain.append(nuovo)
   return "OK", 200
   
@app.route('/nodo/<nodo>', methods=['POST'])
def nodo_peer(nodo):
   nodi.add(nodo)
   return "OK", 200

if __name__=="__main__":
   app.run()

