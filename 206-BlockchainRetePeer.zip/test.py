t1='{"contatto":"Bruno", "messaggio":"Come va?"}'
t2='{"contatto":"Alessia", "messaggio":"Ciao a tutti!"}'
t3='{"contatto":"Ivan", "messaggio":"Oggi è una bella giornata!"}'
t4='{"contatto":"Bruno", "messaggio":"Sono d\'accordo"}'
