const Web3 = require('web3')

const privateKey =''
const from_addr = ''
const to = ''
const web3 = new Web3('http://localhost:7545')


const exec = async () => {
   const transaction = await web3.eth.accounts.signTransaction(
    {
       from: from_addr,
       to: to,
       value: web3.utils.toWei('10','ether'),
       gas: '21000'
    },
    privateKey
   )
   
   const receipt = await web3.eth.sendSignedTransaction(transaction.rawTransaction)
   console.log('Transazione avvenuta con successo. Hash: '+receipt.transactionHash)
   
}

exec()
