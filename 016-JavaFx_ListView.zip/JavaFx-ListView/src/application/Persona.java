/*
 * Screencast
 * JavaFX: ListView e ContextMenu
 *
 * Disponibile su devACADEMY.it
 */

package application;

public class Persona {

	private String nome;
	private String cognome;
	private int eta;
	private boolean automunito;

	@Override
	public String toString() {
		return cognome+" "+nome+", anni "+eta+": "+(automunito?"automunito":"non automunito");
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public int getEta() {
		return eta;
	}
	public void setEta(int eta) {
		this.eta = eta;
	}
	public boolean isAutomunito() {
		return automunito;
	}
	public void setAutomunito(boolean automunito) {
		this.automunito = automunito;
	}

}
