/*
 * Screencast
 * JavaFX: ListView e ContextMenu
 *
 * Disponibile su devACADEMY.it
 */

package application;

import javafx.fxml.FXML;

import javafx.scene.control.Button;

import javafx.scene.control.TextField;

import javafx.event.ActionEvent;

import javafx.scene.control.ListView;

import javafx.scene.control.CheckBox;

public class sceneController {
	@FXML
	private TextField nome;
	@FXML
	private TextField cognome;
	@FXML
	private TextField eta;
	@FXML
	private CheckBox automunito;
	@FXML
	private Button pulsante;
	@FXML
	private ListView listview;

	// Event Listener on Button[#pulsante].onAction
	@FXML
	public void addItem(ActionEvent event) {
		Persona p=new Persona();
		p.setNome(nome.getText());
		p.setCognome(cognome.getText());
		int e=Integer.parseInt(eta.getText());
		p.setEta(e);
		if (automunito.isSelected())
			p.setAutomunito(true);
		else
			p.setAutomunito(false);

		listview.getItems().add(p);

		cleanform();
	}

	private void cleanform()
	{
		nome.clear();
		cognome.clear();
		eta.clear();
		automunito.setSelected(false);
	}

	@FXML
	public void removeItem(ActionEvent event) {
		int selected=listview.getSelectionModel().getSelectedIndex();
		listview.getItems().remove(selected);
		listview.getSelectionModel().clearSelection();
	}
}
