CREATE DATABASE miodb;

USE miodb;

CREATE TABLE campionato(
  squadra VARCHAR(20),
  punti INT
);

INSERT INTO campionato
VALUES
('rossi',12),
('verdi',4),
('arancioni',12),
('azzurri',12),
('gialli',9),
('marroni',5),
('neri',9),
('bianchi',5);