import flask
from flask import request, jsonify

app=flask.Flask(__name__)

@app.get("/")
def ciao():
    return "Buongiorno a tutti!"

@app.post("/user/<id>")
def save_user_data(id):
    user_data=request.get_json()
    name=user_data['name']
    surname=user_data['surname']
    # operazioni di controllo
    # operazioni di salvataggio
    return jsonify(message=f"Salvato utente: {name} {surname} id={id}",
                   data={"ora":"12:34:45"}), 201

if __name__=="__main__":
    app.run()
