<!--

	Screencast
	Come creare un servizio REST completo di database con Slim e MySQL (parte 1)

	Disponibile su devACADEMY.it

-->

<?php

	const DB_URL="localhost";
	const DB_NAME="memo_db";
	const DB_USER="root";
	const DB_PASSWD="";

?>