<!--

	Screencast
	Come creare un servizio REST completo di database con Slim e MySQL (parte 1)

	Disponibile su devACADEMY.it

-->

<?php

	$container = $app->getContainer();

	$container['db'] = function ($container) {
		$pdo = new PDO('mysql:host='.DB_URL.';dbname='.DB_NAME.';charset=utf8',
		                 DB_USER,
						     DB_PASSWD);
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
		return $pdo;
	};

?>