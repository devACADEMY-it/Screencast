<!--

	Screencast
	Come creare un servizio REST completo di database con Slim e MySQL (parte 1)

	Disponibile su devACADEMY.it

-->

<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require 'vendor/autoload.php';

$container = new \Slim\Container;
$app = new \Slim\App($container);

require 'db_config.php';
require 'dependencies.php';

// GET  /memo/quanti

$app->get("/memo/quanti", function(){
	$res=$this->db->query("SELECT COUNT(*) as quanti FROM memo");
	$dati=$res->fetchAll()[0];
	return $this->response->withJson($dati);
});


// GET  /memo/{id} ..... /memo/1

$app->get("/memo/{id}", function($request, $response, $args){

	$id=$args['id'];
	$sql="SELECT * FROM memo WHERE id=:id";
	$st=$this->db->prepare($sql);
	$st->bindParam("id", $id);
	$st->execute();
	$dati=$st->fetchAll();

	if (count($dati)==0)
	{
		$code=404;
		$msg=["errore"=>"Nessuna nota con id $id"];
		return $this->response->withJson($msg, $code);
	}
	return $this->response->withJson($dati[0]);
});

// POST  /memo/nuovo

$app->post("/memo/nuovo", function($request, $response)
{
	$dati=$request->getParsedBody();
	$oggetto=$dati['oggetto'];
	$testo=$dati['testo'];

	$sql="INSERT INTO memo (oggetto, testo) VALUES (:oggetto, :testo)";
	try
	{
	   $st=$this->db->prepare($sql);
	   $st->bindParam("oggetto", $oggetto);
	   $st->bindParam("testo", $testo);

	   $st->execute();
	   $id=$this->db->lastInsertId();
	   $code=201;
	   $res=["id"=>$id];
	}
	catch(PDOException $e)
	{
		 $code=400;
		 $res=["errore"=>"Parametri non validi"];
	}

	return $this->response->withJson($res, $code);
});


$app->run();

?>