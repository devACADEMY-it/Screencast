<!--

	Screencast
	MySQL, gestire dati con le View

	Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<html>
<head>
   <title>Esempio view</title>
   <link rel="stylesheet" type="text/css" href="stile_db.css"/>
</head>
<body>
<div id="centrale">
<table>
<?php

    require_once('config_db.php');
    $stmt = $dbh->query("SELECT * FROM income_count ORDER BY tot DESC");
	foreach($stmt as $row) { ?>
        <tr>
		<td class="sx"><?php echo $row['code']?></div>
		<td class="dx"><?php echo $row['tot']?></div>
        </tr>
    <?php }
?>
</table>
</div>
</body>
</html>