<!--

	Screencast
	MySQL, gestire dati con le View

	Disponibile su devACADEMY.it

-->

<?php

$url="localhost";
$username="myuser";
$password="segreto";
$db="franchise";


try {
    $dbh = new PDO("mysql:host=$url;dbname=$db", $username, $password );

} catch (PDOException $e) {
    print $e->getMessage() . "<br/>";
    die();
}

?>