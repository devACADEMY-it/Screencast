/*
 * Screencast
 * Come gestire le date in PHP con Carbon
 *
 * Disponibile su devACADEMY.it
 */

<?php
	require 'vendor/autoload.php';
	use Carbon\Carbon;

	$adesso=Carbon::now("Europe/Rome");
	echo $adesso;
	echo "<br>";

	echo $adesso->format('d/m/Y');
	echo "<br>";
	echo $adesso->format('H:i:s');
	echo "<br>";

	echo Carbon::createFromDate(2016, 11, 21, "Europe/Rome");
	echo "<br>";
	echo Carbon::createFromTime(18, 32, 11, "Europe/Rome");
	echo "<br>";
	echo Carbon::create(2016, 11, 21, 18,32,11, "Europe/Rome");
	echo "<br>";

	echo Carbon::yesterday();
	echo "<br>";
	echo Carbon::tomorrow();
	echo "<br>";
	echo Carbon::yesterday()->hour(46)->minute(24);
	echo "<br>";

	$tempofa = Carbon::createFromDate(2017, 4, 12);
	echo $adesso->diffInDays($tempofa);
	echo "<br>";
	echo $adesso->diffInHours($tempofa);
	echo "<br>";

?>