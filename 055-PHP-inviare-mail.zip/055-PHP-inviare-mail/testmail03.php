﻿<!--

	Screencast
	Come inviare mail con PHP

	Disponibile su devACADEMY.it

-->

<?php

$headers[] = 'Content-type: text/html; charset=iso-8859-1';
$headers[] = 'From: babbo.natale@lapponia.com (Babbo Natale)';
$headers[] = 'Reply-To: altromioindirizzo@example.com';
$headers[] = 'Fonte: mio-script-php';

$message = '
<html>
<head>
  <title>Un saluto...</title>
</head>
<body>
  <h1>Ciao a tutti!!</h1>
  <h2>Questo è il nostro messaggio</h2>
</body>
</html>
';

echo mail('esempio5698775@gmail.com',
          "Mail HTML via PHP",
          $message,
          implode("\r\n", $headers));
?>