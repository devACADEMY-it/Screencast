<!--

	Screencast
	Come inviare mail con PHP

	Disponibile su devACADEMY.it

-->

<?php

    echo
        mail('esempio5698775@gmail.com',
              'Messaggio via PHP',
              "Ciao, ti arriva?");

?>