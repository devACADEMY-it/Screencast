<!--

	Screencast
	Come inviare mail con PHP

	Disponibile su devACADEMY.it

-->

<?php

$headers[] = 'From: babbo.natale@lapponia.com (Babbo Natale)';
$headers[] = 'Reply-To: altromioindirizzo@example.com';
$headers[] = 'Fonte: mio-script-php';

echo mail('esempio5698775@gmail.com',
          'Messaggio via PHP',
          "Ciao, ti arriva?",
          implode("\r\n", $headers));
?>