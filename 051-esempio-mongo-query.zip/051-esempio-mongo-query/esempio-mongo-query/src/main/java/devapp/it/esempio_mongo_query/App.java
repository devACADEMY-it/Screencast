/*
 * Screencast
 * Java e MongoDB: eseguire query
 *
 * Disponibile su devACADEMY.it
 */

package devapp.it.esempio_mongo_query;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Sorts;

public class App
{
    public static void main( String[] args )
    {
       MongoClient client=new MongoClient();
       MongoDatabase database=client.getDatabase("ricerca_personale");
       MongoCollection<Document> collection=database.getCollection("candidati");

       System.out.println("\nTutti i documenti");
       FindIterable<Document> risultati=collection.find();
       for(Document d:risultati)
       {
    	   System.out.println(d);
       }


       System.out.println("\n\nTutti i sufficienti in Java");
       FindIterable<Document> risultatiJavaSufficienti=collection.find(
    		   		new Document("java", new Document("$gte", 6))
    		   );
       for(Document d:risultatiJavaSufficienti)
       {
    	   System.out.println(d);
       }



       System.out.println("\n\nTutti i sufficienti in PHP con almeno 8 in Java");
       FindIterable<Document> risultatiFiltro1=collection.find(
    		   	 Filters.and(Filters.gte("php", 6), Filters.gte("java", 8))
    		   );
       for(Document d:risultatiFiltro1)
       {
    	   System.out.println(d);
       }



       System.out.println("\n\nDocumenti ordinati");
       FindIterable<Document> risultatiFiltro2=collection.find(
    		   	 Filters.gte("php", 6)
    		   ).sort(Sorts.descending("php"));
       for(Document d:risultatiFiltro2)
       {
    	   System.out.println(d);
       }


       System.out.println("\n\nUso di LIMIT");
       for(Document d:risultatiFiltro2.limit(3))
       {
    	   System.out.println(d);
       }


       client.close();

    }
}