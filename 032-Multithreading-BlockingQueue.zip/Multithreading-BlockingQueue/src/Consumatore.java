/*
 * Screencast
 * Java: Collaborazione multi-threading con BlockingQueue
 *
 * Disponibile su devACADEMY.it
 */

import java.util.concurrent.BlockingQueue;

public class Consumatore implements Runnable
{
	private BlockingQueue<Task> queue=null;

	public Consumatore(BlockingQueue<Task> q) {
		queue=q;
	}

	@Override
	public void run() {
		for (int i=0; i<20; i++)
			try{
				Task t=queue.take();
				System.out.println("               esce   "+t.get());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	}

}