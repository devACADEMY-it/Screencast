/*
 * Screencast
 * Java: Collaborazione multi-threading con BlockingQueue
 *
 * Disponibile su devACADEMY.it
 */

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

class Task
{
	private int valore;

	public Task(int i)
	{
		valore=i;
	}

	int get()
	{
		return valore;
	}
}

public class Main {

	public static void main(String[] args) {

		BlockingQueue<Task> queue=new ArrayBlockingQueue<Task>(20);
		ExecutorService service=Executors.newFixedThreadPool(2);

		service.submit(new Produttore(queue));
		service.submit(new Consumatore(queue));

		service.shutdown();

		try {
			service.awaitTermination(10, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}


	}

}