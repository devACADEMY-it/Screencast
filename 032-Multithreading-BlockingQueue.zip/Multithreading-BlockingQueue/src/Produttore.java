/*
 * Screencast
 * Java: Collaborazione multi-threading con BlockingQueue
 *
 * Disponibile su devACADEMY.it
 */

import java.util.concurrent.BlockingQueue;

public class Produttore implements Runnable
{
	private BlockingQueue<Task> queue=null;

	public Produttore(BlockingQueue<Task> q)
	{
		queue=q;
	}

	@Override
	public void run() {

		for (int i=0; i<20; i++)
			try {
				queue.put(new Task(i));
				System.out.println("entra   "+i);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	}

}