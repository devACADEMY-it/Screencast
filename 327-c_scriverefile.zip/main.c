#include <stdio.h>
#include <stdlib.h>

int main(void) {

  FILE* fptr;

  fptr=fopen("appunti.txt","w");

  if (fptr==NULL){
    printf("Errore nella creazione del file\n");
    exit(EXIT_FAILURE);
  }

  char* msg="Questo è il messaggio da salvare!\n";
  fputs(msg, fptr);

  fclose(fptr);
  
  printf("Salvataggio del file concluso con successo!\n");
  return 0;
}