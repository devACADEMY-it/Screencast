from flask import Flask, request

app=Flask(__name__)

@app.route("/richiesta")
def mostra_form():
   return '''
              <form action="/moltiplica" method="POST">
                  <label for="op1">Operando 1:</label><br>
                  <input type="text" id="op1" name="op1"><br>
                  <label for="op2">Operando 2:</label><br>
                  <input type="text" id="op2" name="op2"><br>
                  <input type="submit" value="Moltiplica!">
              </form>
          '''

@app.route("/moltiplica", methods=['POST'])
def moltiplica():
    op1=request.form.get('op1')
    op2=request.form.get('op2')
    risultato=int(op1)*int(op2)
    return '''
                <h1>{0} X {1} = {2}</h1>
           '''.format(op1, op2, risultato)

if __name__=='__main__':
   app.run()