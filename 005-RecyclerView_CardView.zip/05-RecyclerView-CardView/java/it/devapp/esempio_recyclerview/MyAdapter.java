package it.devapp.esempio_recyclerview;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>
{
    private List<String> lista;

    public static class ViewHolder extends RecyclerView.ViewHolder
    {
        public TextView testo;
        public TextView lunghezza;

        public ViewHolder(View v)
        {
            super(v);
            testo= (TextView) v.findViewById(R.id.testo);
            lunghezza= (TextView) v.findViewById(R.id.lunghezza);
        }
    }

    public MyAdapter(){
        lista=new ArrayList<String>();
    }
    @Override
    public MyAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);

        MyAdapter.ViewHolder vh=new ViewHolder(v);

        return vh;
    }

    @Override
    public void onBindViewHolder(MyAdapter.ViewHolder holder, int position) {

        String tmp=lista.get(position);
        holder.testo.setText(tmp);
        holder.lunghezza.setText("("+tmp.length()+" caratteri)");
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    public void addString(String t)
    {
        lista.add(t);
        notifyDataSetChanged();
    }
}