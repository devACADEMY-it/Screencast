/*
 * Screencast 
 * Flutter: costruire layout
 *
 * Disponibile su devACADEMY.it
 */

import 'package:flutter/material.dart';

final nome_citta="Venezia";
final descrizione_citta="Venezia, il capoluogo della regione Veneto, è adagiata su più di 100 "
    "piccole isole all'interno di una laguna nel mare Adriatico. In questa città non esistono "
    "strade ma canali, tra cui il Canal Grande, fiancheggiato da palazzi rinascimentali e gotici. "
    "Sulla piazza centrale, piazza San Marco, sorgono la Basilica di San Marco, arricchita da mosaici "
    "bizantini, e il campanile di San Marco, da cui si possono ammirare i tetti rossi della città.";

class MyHome extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(
          title: Text("Benvenuti a Venezia")
       ),
      body: Column(
        children: <Widget>[
          Image.asset("images/venezia.jpg",
            fit: BoxFit.cover),
          Container(
            padding: EdgeInsets.all(10),
            width: double.infinity,
            decoration: BoxDecoration(
              color: Color(0xff7c94b6),
              border: Border.all(
                color: Colors.black12,
                width: 8,
              )
            ),
            child: Text(nome_citta,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 35,
                fontWeight: FontWeight.bold
              )
            ),
          ),
          Container(
            padding: EdgeInsets.all(10),
            child: Text(
              descrizione_citta,
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 20
              ),
            )
          )
        ],
      ),
    );
  }


}

void main(){
    runApp(
      MaterialApp(
        title: "Benvenuti a Venezia",
        home: MyHome()
      )
    );
}