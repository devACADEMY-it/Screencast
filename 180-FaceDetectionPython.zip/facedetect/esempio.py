import cv2
model=cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
img=cv2.imread('immagine.jpg')
img2=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
faces=model.detectMultiScale(img2, 1.2, 2)
print(f'Facce individuate: {len(faces)}')
for f in faces:
   print(f)

x0,y0,d1,d2=faces[0]
cv2.rectangle(img, (x0,y0), (x0+d1, y0+d2), (255,255,0), 2)
x0,y0,d1,d2=faces[1]
cv2.rectangle(img, (x0,y0), (x0+d1, y0+d2), (255,255,0), 2)
cv2.imwrite('evidenziata.jpg', img)
