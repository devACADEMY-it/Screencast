/*
 * Screencast
 * Firebase, Cloud Functions con database Firestore
 *
 * Disponibile su devACADEMY.it
 */

const functions = require('firebase-functions');
const admin = require('firebase-admin')

admin.initializeApp(functions.config().firebase)
const db=admin.firestore()

const collectionName='log'

function now(){
	today=new Date()
	return today.getHours()+":"+today.getMinutes()+":"+today.getSeconds()
}

exports.helloWorld=functions.https.onRequest((request, response) =>
{
	db.collection(collectionName)
	  .doc('helloWorld')
	    .set({"time":now()})
	response.send("Hello world!")
})

exports.last=functions.https.onRequest((request, response) =>
{
	// https://_______/last?fun=helloWorld
	db.collection(collectionName)
	  .doc(request.query.fun)
	   .get()
	     .then(
			doc => {
				if (!doc.exists)
					response.send("Funzione mai invocata")
				else
					response.send(doc.id+" : "+doc.data().time)
			}
		 )
})