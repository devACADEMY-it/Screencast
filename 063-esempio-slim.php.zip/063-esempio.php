<!--

	Screencast
	Slim Framework: richieste e risposte in JSON

	Disponibile su devACADEMY.it

-->

<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require 'vendor/autoload.php';

$app = new \Slim\App;

$app->get('/hello', function (Request $request, Response $response) {

	$dati=array("messaggio" => "Ciao JSON!");
	$json_response=$response->withJSON($dati, 201);
	return $json_response;
});

function parametri_validi($body)
{
	return !is_null($body) &&
			array_key_exists('a', $body) &&
			array_key_exists('b', $body) &&
			is_numeric($body['a']) &&
			is_numeric($body['b']);

}

$app->post('/calcolo', function (Request $request, Response $response) {

	$body=$request->getParsedBody();
	if (parametri_validi($body))
	{
		$dati=array('risultato' => $body['a']+$body['b']);
		$code=200;
	}
	else
	{
		$dati=array('errore' => "argomenti non numerici");
		$code=400;
	}

	return $response->withJson($dati, $code);

	/*$body=$request->getParsedBody();
	$dati=array('risultato' => $body['a']+$body['b']);
	return $response->withJson($dati);*/
});

$app->run();

?>