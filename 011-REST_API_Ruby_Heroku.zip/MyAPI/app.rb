require 'grape'

class SampleApi < Grape::API

	version 'v1', using: :path
	format :json
	prefix :api

	get '/now' do
		{:result => Time.now()}
	end
end