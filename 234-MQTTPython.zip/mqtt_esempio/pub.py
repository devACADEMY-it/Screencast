import paho.mqtt.client as mqtt

def on_publish(client, userdata, result):
    print(f'Messaggio inviato...')
	
mqttbroker='mqtt.eclipseprojects.io'
client = mqtt.Client("prova")
client.on_publish=on_publish
client.connect(mqttbroker)

while(True):
    msg=input(">    ")
    if msg=='BASTA':
        break
    client.publish("MESSAGGIO", msg)