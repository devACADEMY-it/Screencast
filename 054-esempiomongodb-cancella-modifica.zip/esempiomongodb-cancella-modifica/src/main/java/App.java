/*
 * Screencast
 * Java e MongoDB: cancellare e modificare document
 *
 * Disponibile su devACADEMY.it
 */

import java.util.HashMap;

import org.bson.Document;
import org.bson.types.ObjectId;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;

public class App {

	public static void main(String[] args) {

		MongoClient client=new MongoClient();
		MongoDatabase db=client.getDatabase("ricerca_personale");
		MongoCollection<Document> collection=db.getCollection("candidati");

		HashMap<String, Object> nuoviValori=new HashMap();
		nuoviValori.put("java", 6);
		nuoviValori.put("inglese", 8);

		Document up=collection.findOneAndUpdate(Filters.eq("nominativo", "Gialli Valeria"),
						new Document("$set", new Document(nuoviValori)));

		System.out.println(up);

		Document d=collection.find(Filters.eq("nominativo", "Gialli Valeria")).first();
		System.out.println(d);

		Document res=collection.findOneAndDelete(Filters.eq("_id", new ObjectId("59db51885049c0228fa945d8")));
		System.out.println(res);

		UpdateResult ur=collection.updateOne(Filters.eq("nominativo", "Rossi Enzo"),
				new Document("$set", new Document(nuoviValori)));
		System.out.println(ur);


		DeleteResult dr=collection.deleteMany(Filters.lte("inglese", 6));
		System.out.println(dr);






		client.close();


	}

}
