<!--

	Screencast
	Come creare un servizio REST completo di database con Slim e MySQL (parte 2)

	Disponibile su devACADEMY.it

-->

<?php

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require 'vendor/autoload.php';

$container = new \Slim\Container;
$container['errorHandler'] = function ($c) {
    return function ($request, $response, $exception) use ($container) {
        return $container['response']->withStatus(404)
                             ->withHeader('Content-Type', 'text/html')
                             ->write('Something went wrong!');
    };
};

$app = new \Slim\App($container);

require 'db_config.php';
require 'dependencies.php';

// GET  /memo/quanti

$app->get("/memo/quanti", function(){
	$res=$this->db->query("SELECT COUNT(*) as quanti FROM memo");
	$dati=$res->fetchAll()[0];
	return $this->response->withJson($dati);
});


// GET  /memo/{id} ..... /memo/1

$app->get("/memo/{id}", function($request, $response, $args){

	$id=$args['id'];
	$sql="SELECT * FROM memo WHERE id=:id";
	$st=$this->db->prepare($sql);
	$st->bindParam("id", $id);
	$st->execute();
	$dati=$st->fetchAll();

	if (count($dati)==0)
	{
		$code=404;
		$msg=["errore"=>"Nessuna nota con id $id"];
		return $this->response->withJson($msg, $code);
	}
	return $this->response->withJson($dati[0]);
});

// POST  /memo/nuovo

$app->post("/memo/nuovo", function($request, $response)
{
	$dati=$request->getParsedBody();
	$oggetto=$dati['oggetto'];
	$testo=$dati['testo'];

	$sql="INSERT INTO memo (oggetto, testo) VALUES (:oggetto, :testo)";
	try
	{
	   $st=$this->db->prepare($sql);
	   $st->bindParam("oggetto", $oggetto);
	   $st->bindParam("testo", $testo);

	   $st->execute();
	   $id=$this->db->lastInsertId();
	   $code=201;
	   $res=["id"=>$id];
	}
	catch(PDOException $e)
	{
		 $code=400;
		 $res=["errore"=>"Parametri non validi"];
	}

	return $this->response->withJson($res, $code);
});

$app->delete("/memo[/{id:[0-9]+}]", function($request, $response, $args)
	{
		if (array_key_exists('id', $args))
		{
			$sql="DELETE FROM memo WHERE id=:id";
			$id=$args['id'];
			$st=$this->db->prepare($sql);
			$st->bindParam('id', $id);
			$st->execute();
			$cancellate=$st->rowCount();
		}
		else
			$cancellate=$this->db->exec("DELETE FROM memo");

		if ($cancellate>0)
		{
			$code=200;
			$msg=["msg"=>"Cancellazione eseguita"];
		}
		else
		{
			$code=404;
			$msg=["errore"=>"Nessuna nota cancellata"];
		}

		return $this->response->withJson($msg, $code);

	});


$app->put("/memo/{id}", function($request, $response, $args){

	$id=$args['id'];
	$dati=$request->getParsedBody();

	try {

		$set[]="data_modifica='".date("Y-m-d H:i:s")."'";
		if (array_key_exists("testo", $dati))
			$set[]="testo='".$dati['testo']."'";
		if (array_key_exists("oggetto", $dati))
			$set[]="oggetto='".$dati['oggetto']."'";

		if (count($set)>1)
		{
			$sql="UPDATE memo SET ".implode(",", $set)." WHERE id=:id";
			$st=$this->db->prepare($sql);
			$st->bindParam('id', $id);
			$st->execute();
			$code=200;
			$res=["id"=>$id];
			if ($st->rowCount()>0)
				$res["modificato"]=true;
			else
				$res["modificato"]=false;
		}

	}
	catch(PDOException $e)
	{
		$code=400;
		$res=["errore"=>"Parametri non validi"];
	}

	return $this->response->withJson($res, $code);

});

$app->run();

?>