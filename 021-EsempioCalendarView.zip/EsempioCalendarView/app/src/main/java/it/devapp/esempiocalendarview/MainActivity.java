/*
 * Screencast
 * Android: inserimento di date con CalendarView
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.esempiocalendarview;

import android.app.Dialog;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.EditText;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private EditText data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        data= (EditText) findViewById(R.id.data_selezionata);
    }

    public void apriCalendario(View v)
    {
        CalendarView calendarView=new CalendarView(this);

        final Dialog dialog=new AlertDialog.Builder(this)
                .setView(calendarView)
                .setPositiveButton("Chiudi", null)
                .show();

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView calendarView, int year, int month, int dayOfMonth) {
                data.setText(dayOfMonth+"/"+(month+1)+"/"+year);
                dialog.dismiss();
            }
        });

        calendarView.setMinDate(new Date().getTime());
        calendarView.setMaxDate(new Date().getTime()+10*24*3600*1000);
    }
}