/*
 * Screencast
 * DateTime API
 *
 * Disponibile su devACADEMY.it
 */

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class Main {

	public static void main(String[] args) {

		LocalDate ld=LocalDate.of(2017, 2, 1);

		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");

		String s=ld.format(formatter);

		System.out.println(s);

		String s1=ld.plusDays(16).format(formatter);
		System.out.println(s1);

		String s2=ld.minusDays(16).format(formatter);
		System.out.println(s2);

		System.out.println(ld.getYear());
		System.out.println(ld.getMonthValue());
		System.out.println(ld.getDayOfMonth());
		System.out.println(ld.getDayOfYear());

		if (ld.isBefore(LocalDate.now()))
		{
			long giorniTrascorsi=ld.until(LocalDate.now(), ChronoUnit.DAYS);
			System.out.println("Sono passati "+giorniTrascorsi+" giorni");
		}

		LocalTime lt=LocalTime.of(18, 25);
		DateTimeFormatter formatter1=DateTimeFormatter.ofPattern("HH:mm");

		String st=lt.format(formatter1);
		System.out.println("Ora : "+st);

		LocalDateTime ldt=LocalDateTime.of(ld, lt);
		DateTimeFormatter formatter2=DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
		System.out.println(ldt.format(formatter2));

		System.out.println("Aspettiamo 3 secondi...");
		Instant i1=Instant.now();

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Instant i2=Instant.now();
		System.out.println(i2.getEpochSecond()-i1.getEpochSecond());

	}

}
