/*
 * Screencast
 * Android, gestire relazioni uno-a-molti con Room
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.roomrelazioni;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    private ArrayAdapter<Paese> paeseAdapter;
    private ArrayAdapter<Citta> cittaAdapter;

    private Spinner paesi;
    private ListView citta;

    private CittaDao cittaDao;

    private void inizializzaDatabase()
    {
        long[] ids=cittaDao.insertPaese(
                new Paese("Italia"),
                new Paese("Spagna"),
                new Paese("Francia"),
                new Paese("Germania")
        );

        cittaDao.insertCitta(new Citta("Roma", ids[0]),
                new Citta("Milano", ids[0]),
                new Citta("Torino", ids[0]),
                new Citta("Madrid", ids[1]),
                new Citta("Barcellona", ids[1]),
                new Citta("Parigi", ids[2]),
                new Citta("Marsiglia", ids[2]),
                new Citta("Nizza", ids[2]),
                new Citta("Berlino", ids[3]),
                new Citta("Stoccarda", ids[3]));

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        paesi=findViewById(R.id.paesi);
        citta=findViewById(R.id.citta);

        cittaDao=CittaDatabase.getInMemoryDatabase(this).cittaModel();

        inizializzaDatabase();
        inizializzaUI();
    }

    private void inizializzaUI()
    {
        paeseAdapter=new ArrayAdapter<Paese>(this,
                android.R.layout.simple_list_item_1,
                cittaDao.caricaTuttiPaesi());

        cittaAdapter=new ArrayAdapter<Citta>(this,
                android.R.layout.simple_list_item_1);

        paesi.setAdapter(paeseAdapter);
        citta.setAdapter(cittaAdapter);

        paesi.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cittaAdapter.clear();
                Paese p=paeseAdapter.getItem(position);
                cittaAdapter.addAll(cittaDao.listaCittaPerPaese(p.id));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}