/*
 * Screencast
 * Android, gestire relazioni uno-a-molti con Room
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.roomrelazioni;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import static android.arch.persistence.room.ForeignKey.CASCADE;

@Entity( foreignKeys = @ForeignKey(entity=Paese.class,
    parentColumns = "id",
    childColumns = "idPaese",
    onDelete = CASCADE))

public class Citta {

    @PrimaryKey(autoGenerate = true)
    @NonNull
    public long id;

    public String nomeCitta;
    public long idPaese;

    public Citta(String nomeCitta, long idPaese)
    {
        this.nomeCitta=nomeCitta;
        this.idPaese=idPaese;
    }

    @Override
    public String toString() {
        return nomeCitta;
    }
}