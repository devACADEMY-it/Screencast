/*
 * Screencast
 * Android, gestire relazioni uno-a-molti con Room
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.roomrelazioni;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;

import static android.arch.persistence.room.OnConflictStrategy.REPLACE;

@Dao
interface CittaDao {

    @Insert(onConflict = REPLACE)
    long[] insertPaese(Paese... paese);

    @Insert(onConflict = REPLACE)
    long[] insertCitta(Citta... citta);

    @Query("SELECT * FROM Paese")
    List<Paese> caricaTuttiPaesi();

    @Query("SELECT * FROM Citta WHERE idPaese=:idPaese")
    List<Citta> listaCittaPerPaese(long idPaese);

}