/*
 * Screencast
 * Android, gestire relazioni uno-a-molti con Room
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.roomrelazioni;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

@Database(entities = {Citta.class, Paese.class}, version = 1)
public abstract class CittaDatabase extends RoomDatabase {

    private static CittaDatabase INSTANCE;

    public abstract CittaDao cittaModel();

    public static CittaDatabase getInMemoryDatabase(Context context) {
        if (INSTANCE == null) {
            INSTANCE =
                    Room.inMemoryDatabaseBuilder(context.getApplicationContext(), CittaDatabase.class)
                            .allowMainThreadQueries()
                            .build();
        }
        return INSTANCE;
    }

}