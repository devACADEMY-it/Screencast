/*
 * Screencast
 * Android, gestire relazioni uno-a-molti con Room
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.roomrelazioni;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

@Entity
public class Paese {

    @PrimaryKey(autoGenerate = true)
    @NonNull
    public long id;

    public String nomePaese;

    public Paese(String nomePaese)
    {
        this.nomePaese=nomePaese;
    }

    @Override
    public String toString() {
        return nomePaese;
    }
}