/*
 * Screencast
 * Realizzare interfacce web con Thymeleaf
 *
 * Disponibile su devACADEMY.it
 */

package introspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App {

	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}

}
