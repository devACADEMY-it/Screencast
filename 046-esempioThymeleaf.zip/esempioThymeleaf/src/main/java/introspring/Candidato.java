/*
 * Screencast
 * Realizzare interfacce web con Thymeleaf
 *
 * Disponibile su devACADEMY.it
 */

package introspring;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Candidato {

	enum Genere
	{
		MASCHIO, FEMMINA
	}

	static class Competenza
	{
		private String titolo;
		private int voto;

		Competenza(String titolo, int voto)
		{
			this.titolo=titolo;
			this.voto=voto;
		}
		public String getTitolo() {
			return titolo;
		}
		public int getVoto() {
			return voto;
		}

	}

	private String nome;
	private String citta;
	private LocalDate nascita;
	private Genere genere;
	private boolean automunito;
	private List<Competenza> competenze=new ArrayList<Competenza>();

	public Candidato(String nome, String citta, LocalDate nascita)
	{
		this.nome = nome;
		this.citta = citta;
		this.nascita = nascita;
	}

	public void setGenere(Genere genere) {
		this.genere = genere;
	}

	public void setAutomunito(boolean automunito) {
		this.automunito = automunito;
	}

	public void addCompetenza(Competenza competenza) {
		competenze.add(competenza);
	}

	public String getNome()
	{
		return nome;
	}

	public String getNascita()
	{
		if (nascita==null)
			return null;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/LL/yyyy");
		String formattedString = nascita.format(formatter);
		return formattedString;
	}

	public String getCitta()
	{
		return citta;
	}

	public Genere getGenere()
	{
		return genere;
	}

	public boolean isAutomunito()
	{
		return automunito;
	}

	public List<Competenza> getCompetenze()
	{
		return competenze;
	}

}
