/*
 * Screencast
 * Realizzare interfacce web con Thymeleaf
 *
 * Disponibile su devACADEMY.it
 */

package introspring;

import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import introspring.Candidato.Competenza;
import introspring.Candidato.Genere;


@Controller
public class MyController{


	@RequestMapping("/")
	public String home(Model model)
	{
		Candidato candidato=new Candidato("Sabrina Verdi", "Roma", LocalDate.of(1979, 5, 16));
		candidato.setGenere(Genere.FEMMINA);
		candidato.setAutomunito(false);
		candidato.addCompetenza(new Competenza("Java", 9));
		candidato.addCompetenza(new Competenza("PHP", 7));
		candidato.addCompetenza(new Competenza("Inglese", 9));
		candidato.addCompetenza(new Competenza("SQL", 10));

		model.addAttribute("candidato", candidato);
		return "home";
	}

}
