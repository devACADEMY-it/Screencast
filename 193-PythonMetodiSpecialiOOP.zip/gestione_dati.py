class Corso:
  def __init__(self):
     self.allievi=[]

  def __add__(self, nuovo):
     self.allievi.append(nuovo)
	 
  def __len__(self):
     return len(self.allievi)

  def __getitem__(self, posizione):
     if 0<=posizione<len(self.allievi):
        return self.allievi[posizione]

  def __setitem__(self, posizione, nuovo):
     self.allievi[posizione]=nuovo
		
  def __contains__(self, allievo):
     return allievo in self.allievi
  
