/*
 * Screencast
 * Salvare dati nelle SharedPreferences
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.esempiosharedpreferences;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private int numero;
    private TextView txt_numero;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt_numero= (TextView) findViewById(R.id.txt_numero);

        numero=getPreferences(Context.MODE_PRIVATE)
                .getInt("numero_salvato", 0);

        txt_numero.setText( Integer.toString(numero));
    }

    public void incrementa(View v)
    {
        numero++;
        txt_numero.setText( Integer.toString(numero));
    }

    public void decrementa(View v)
    {
        numero--;
        txt_numero.setText( Integer.toString(numero));
    }

    @Override
    protected void onPause() {
        super.onPause();
        getPreferences(Context.MODE_PRIVATE)
                .edit()
                .putInt("numero_salvato", numero)
                .apply();
    }
}
