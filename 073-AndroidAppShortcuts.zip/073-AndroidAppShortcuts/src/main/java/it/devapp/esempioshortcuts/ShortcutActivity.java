/*
 * Screencast
 * Android: attivare velocemente funzionalità delle app con gli Shortcuts
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.esempioshortcuts;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class ShortcutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shortcut);
    }
}