import flask

app=flask.Flask(__name__)

@app.get("/")
def ciao():
    return "Buongiorno a tutti!"

@app.get("/tabellina/<numero>")
def tabellina(numero):
    res=''
    try:
      numero=int(numero)
      if numero<=0:
          return "Il numero deve essere un intero maggiore di zero", 400
    except:
          return "Il parametro deve essere un numero intero", 400
    for i in range(1,11):
      res+=f'{i} X {numero} = {i*numero}<br>'
    return res

if __name__=="__main__":
    app.run()
