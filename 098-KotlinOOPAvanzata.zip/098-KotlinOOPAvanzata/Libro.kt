/*
 * Screencast 
 * Kotlin, programmazione a oggetti avanzata
 *
 * Disponibile su devACADEMY.it
 */

open class Libro(titolo:String, pagine:Int) : Opera(titolo){

    init{
        controlloNumeroPagine(pagine)
    }

    private fun controlloNumeroPagine(pagine:Int)
    {
        if (pagine<=0)
            throw IllegalArgumentException("Numero pagine non valido")
    }

    var numeroPagine:Int=pagine

    override fun stampaScheda() {
        println("Titolo: $titolo")
        if (autoreAnonimo())
            println("Autore anonimo")
        else if (!autoriVari())
            println("Autore: ${autori.first()}")
        else
            autori.iterator().forEach { println("- $it") }
        println("$numeroPagine pagine")
    }
}