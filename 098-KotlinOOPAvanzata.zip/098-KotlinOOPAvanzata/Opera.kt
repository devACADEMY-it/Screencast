/*
 * Screencast 
 * Kotlin, programmazione a oggetti avanzata
 *
 * Disponibile su devACADEMY.it
 */

abstract class Opera(titolo: String) {

    val titolo=titolo

    val autori= mutableListOf<String>()

    fun autoreAnonimo() = autori.size==0

    fun autoriVari() = autori.size>1

    fun aggiungiAutori(vararg nuoviAutori:String)
    {
        autori.addAll(nuoviAutori)
    }

    abstract fun stampaScheda()
}