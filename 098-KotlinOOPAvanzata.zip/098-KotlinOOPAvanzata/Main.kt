/*
 * Screencast 
 * Kotlin, programmazione a oggetti avanzata
 *
 * Disponibile su devACADEMY.it
 */

fun main(args:Array<String>)
{
    try {
        val libro = Libro("Come curare il giardino", 520)
        libro.aggiungiAutori("Bianchi Emilio", "Verdi Sara")
        libro.stampaScheda()

        println("\n\n")

        val libroPrestabile = LibroPrestabile("Conversazioni in inglese", -85)
        libroPrestabile.aggiungiAutori("Rossi Nicola")
        libroPrestabile.inizioPrestito()
        libroPrestabile.stampaScheda()

        println("\n\n")

        libroPrestabile.finePrestito()
        libroPrestabile.stampaScheda()
    }
    catch(ill:IllegalArgumentException)
    {
        println("Errore: argomento non valido")
    }
}