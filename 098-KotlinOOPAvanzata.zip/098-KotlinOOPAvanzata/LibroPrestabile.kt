/*
 * Screencast 
 * Kotlin, programmazione a oggetti avanzata
 *
 * Disponibile su devACADEMY.it
 */

import java.time.LocalDate
import java.time.format.DateTimeFormatter

class LibroPrestabile (titolo:String, pagine: Int): Libro(titolo, pagine){

    private val formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy")
    private val durata_prestito=14L

    private var inPrestito:Boolean=false

    private var scadenzaPrestito: LocalDate?=null

    fun inizioPrestito()
    {
        if (!inPrestito)
        {
            scadenzaPrestito= LocalDate.now().plusDays(durata_prestito)
            inPrestito=true
        }
    }

    fun finePrestito()
    {
        if (inPrestito)
        {
            scadenzaPrestito=null
            inPrestito=false
        }
    }

    override fun stampaScheda() {
        super.stampaScheda()
        if (inPrestito)
            println("Attualmente in prestito fino al ${scadenzaPrestito?.format(formatter)}")
        else
            println("Attualmente non in prestito")
    }
}