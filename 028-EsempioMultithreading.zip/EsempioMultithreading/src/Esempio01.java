/*
 * Screencast
 * Programmazione concorrente con Thread ed Executors
 *
 * Disponibile su devACADEMY.it
 */

class Esecuzione extends Thread
{
	private String nome;

	Esecuzione(String nome)
	{
		this.nome=nome;
	}

	@Override
	public void run() {

		long id=Thread.currentThread().getId();
		for (int i=0; i<7; i++)
			System.out.println(nome+" ("+id+") stampa "+i);
	}
}

public class Esempio01 {

	public static void main(String[] args) {

		long id=Thread.currentThread().getId();
		System.out.println("Main ha id = "+id);

		new Esecuzione("ROSSO").start();
		new Esecuzione("VERDE").start();
		new Esecuzione("BIANCO").start();

	}

}
