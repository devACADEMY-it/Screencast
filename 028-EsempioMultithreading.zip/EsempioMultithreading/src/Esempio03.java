/*
 * Screencast
 * Programmazione concorrente con Thread ed Executors
 *
 * Disponibile su devACADEMY.it
 */

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

class ScriviFile implements Runnable
{

	@Override
	public void run() {
		String nome="Nuovo-"+Thread.currentThread().getId()+".txt";

		try(BufferedWriter bw=Files.newBufferedWriter(Paths.get(nome)))
		{
			for (int i=0; i<20; i++)
			{
				bw.write("Iterazione n. "+i);
				bw.newLine();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

public class Esempio03 {

	public static void main(String[] args) throws InterruptedException {

		ExecutorService executor=Executors.newFixedThreadPool(5);
		long inizio =System.nanoTime();

		for (int k=0; k<5; k++)
			executor.submit(new ScriviFile());

		long fine =System.nanoTime();

		System.out.println(fine-inizio);



	}

}
