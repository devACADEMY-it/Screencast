/*
 * Screencast
 * Programmazione concorrente con Thread ed Executors
 *
 * Disponibile su devACADEMY.it
 */

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Esempio02 {

	public static void main(String[] args) {

		long inizio =System.nanoTime();

		for (int k=0; k<5; k++)
		{
			String nome="Nuovo-0"+k+".txt";

			try(BufferedWriter bw=Files.newBufferedWriter(Paths.get(nome)))
			{
				for (int i=0; i<20; i++)
				{
					bw.write("Iterazione n. "+i);
					bw.newLine();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		long fine =System.nanoTime();

		System.out.println(fine-inizio);


	}


	}

