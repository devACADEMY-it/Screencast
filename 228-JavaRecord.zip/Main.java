record Studente(String nome, String matricola, int eta){};

/*class Studente{
    private final String nome;
    private final String matricola;
    private final int eta;

    Studente(String nome, String matricola, int eta){
        this.nome=nome;
        this.matricola=matricola;
        this.eta=eta;
    }

    public String nome(){
        return this.nome;
    }

    public String matricola(){
        return this.matricola;
    }

    public int eta(){
        return this.eta;
    }
}*/

public class Main{

    public final static void main(String[] args){
        Studente allievo=new Studente("Gianni Rossi", "A12345", 19);
        System.out.println("Il nome dell'allievo è: "+allievo.nome());
    }
}