/*
 * Screencast
 * Android: gestire le transazioni in SQLite
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.androidtransazioni;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private DbManager db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db=new DbManager(this);
    }


    public void transazioneCorretta(View view) {
        Toast.makeText(this, db.transazioneCorretta(), Toast.LENGTH_LONG).show();
    }

    public void transazioneConErrore(View view) {
        Toast.makeText(this, db.transazioneConErrore(), Toast.LENGTH_LONG).show();
    }

}