/*
 * Screencast
 * Android: gestire le transazioni in SQLite
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.androidtransazioni;

import android.content.Context;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

public class DbManager {

    private static final String DB_CREATE =
            "CREATE TABLE log " +
                    "( _id integer primary key," +
                    "  messaggio text not null);";

    private SQLiteOpenHelper helper;

    public DbManager(Context context)
    {
        helper=new SQLiteOpenHelper(context, "database", null, 1) {
            @Override
            public void onCreate(SQLiteDatabase db) {
                db.execSQL(DB_CREATE);
            }

            @Override
            public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

            }
        };
    }

    public String transazioneCorretta()
    {
        String[] comandi={
                "INSERT INTO log (messaggio) VALUES ('Primo messaggio')",
                "INSERT INTO log (messaggio) VALUES ('Secondo messaggio')",
                "INSERT INTO log (messaggio) VALUES ('Terzo messaggio')"
        };

        return eseguiTransazione(comandi);
    }

    public String transazioneConErrore()
    {
        String[] comandi={
                "INSERT INTO log (messaggio) VALUES ('Primo messaggio')",
                "INSERT INTO log (messaggio) VALUES ('Secondo messaggio')",
                /*ATTENZIONE ... comando VOLUTAMENTE sbagliato! */
                "INSERT INTO log (messaggio)  ('Terzo messaggio')"
        };

        return eseguiTransazione(comandi);
    }

    private String eseguiTransazione(String[] comandi)
    {
        SQLiteDatabase db=helper.getWritableDatabase();

        db.beginTransaction();
        try
        {
            for(String c:comandi)
                db.execSQL(c);
            db.setTransactionSuccessful();
        }
        catch(SQLiteException e)
        {
            return "ERRORE: inserimento fallito!";
        }
        finally {
           db.endTransaction();
        }

        return "La tabella contiene "+DatabaseUtils.queryNumEntries(db, "log")+" record";

    }

}