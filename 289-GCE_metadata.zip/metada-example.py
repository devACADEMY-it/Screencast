import requests
times=requests.get("http://metadata.google.internal/computeMetadata/v1/instance/attributes/iterations", headers={"Metadata-Flavor":"Google"})

for i in range(0, int(times.text)):
    print(f">>>> {i}")