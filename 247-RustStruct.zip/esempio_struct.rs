struct Autore(String, String, String);

#[allow(dead_code)]
#[derive(Eq, PartialEq)]
enum Genere{
    Narrativa,
    Saggistica,
    Dizionari
}

#[allow(dead_code)]
struct Libro{
    titolo: String,
    autore: Autore,
    pagine: u16,
    genere: Genere
}

fn main() {
    let dati_autore= Autore(String::from("Ugo Verdi"), 
    String::from("Esperto di botanica"),
    String::from("Docente presso l'Università di Milano"));
    
    let manuale=Libro{ titolo:String::from("Un giardino stupendo"), 
    autore:dati_autore, pagine:620, genere: Genere::Saggistica};
    
    if manuale.genere==Genere::Narrativa{
        println!("Capolavoro di NARRATIVA...");
    }
    else if manuale.genere==Genere::Saggistica{
        println!("Capolavoro di SAGGISTICA...");
    }
    else {
        println!("Un grande dizionario...");
    }
    
    println!("In vendita il nuovo manuale \"{}\" di {}, {}. {} pagine tutte da leggere!", 
     manuale.titolo, manuale.autore.0, manuale.autore.1, manuale.pagine);
}