import java.math.BigInteger;

public class EsempioBigInteger {

	public static void main(String[] args) {
			BigInteger numeroGrande=BigInteger.valueOf(754573);
			BigInteger daStringa=new BigInteger("34573458348398");
			System.out.println("Numero grande: "+numeroGrande);
			System.out.println("Da stringa: "+daStringa);
			System.out.println();
			
			BigInteger risultato=BigInteger.ONE;
			for (int i=1; i<=10; i++) {
				risultato=risultato.multiply(BigInteger.valueOf(i));
				System.out.println("Iterazione #"+i+": risultato="+risultato);
			}
			System.out.println();
			
			System.out.println("Elevato alla 10 "+risultato.pow(10));
			
	}
}
