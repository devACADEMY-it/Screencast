package main
import "fmt"
func main(){
	var punt *int
	var numero int=500
	
	punt = &numero
	
	fmt.Printf("Valore della variabile %d\n", numero)
	fmt.Printf("Valore della variabile %x\n", &numero)
	fmt.Printf("Valore della variabile %x\n", punt)
	
	*punt = 600
	
	fmt.Printf("Valore della variabile %d\n", numero)
}