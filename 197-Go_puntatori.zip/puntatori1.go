package main
import "fmt"
func main(){
	var a int=100
	fmt.Printf("Valore della variabile %d\n", a)
	fmt.Printf("Indirizzo della variabile %x\n", &a)
	
	var b int=200
	fmt.Printf("Valore della variabile %d\n", b)
	fmt.Printf("Indirizzo della variabile %x\n", &b)
}