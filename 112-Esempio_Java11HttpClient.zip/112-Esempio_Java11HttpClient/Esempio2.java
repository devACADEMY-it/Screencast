/*
 * Screencast
 * Java 11: nuovo client per HTTP e WebSocket
 *
 * Disponibile su devACADEMY.it
 */

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpHeaders;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandler;
import java.util.stream.Stream;

public class Esempio2 {

	public static void main(String[] args) {

		HttpClient client=HttpClient.newHttpClient();

		HttpRequest req=HttpRequest.newBuilder()
							.uri(URI.create("http://localhost/dati.txt"))
								.build();

		BodyHandler<Stream<String>> handler= HttpResponse.BodyHandlers.ofLines();

		try {
			HttpResponse<Stream<String>> res=client.send(req, handler);

			res.body().filter(x -> x.contains("Roma")).forEach(System.out::println);

		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}


	}

}