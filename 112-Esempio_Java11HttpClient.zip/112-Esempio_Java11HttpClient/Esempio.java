/*
 * Screencast
 * Java 11: nuovo client per HTTP e WebSocket
 *
 * Disponibile su devACADEMY.it
 */

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpHeaders;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class Esempio {

	public static void main(String[] args) {

		HttpClient client=HttpClient.newHttpClient();

		HttpRequest req=HttpRequest.newBuilder()
							.uri(URI.create("http://localhost/dati.txt"))
								.build();

		HttpResponse.BodyHandler<String> handler= HttpResponse.BodyHandlers.ofString();

		try {
			HttpResponse<String> res=client.send(req, handler);
			//System.out.println(res.body());

			HttpHeaders headers=res.headers();
			System.out.println(headers.firstValue("Server"));

		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}


	}

}