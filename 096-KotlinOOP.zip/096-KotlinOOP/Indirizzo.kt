/*
 * Screencast 
 * Kotlin: Programmazione Orientata agli Oggetti
 *
 * Disponibile su devACADEMY.it
 */

data class Indirizzo(val citta:String,
                        val indirizzoConCivico:String,
                            val cap: String)