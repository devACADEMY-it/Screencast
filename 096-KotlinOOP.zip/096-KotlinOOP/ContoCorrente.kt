/*
 * Screencast 
 * Kotlin: Programmazione Orientata agli Oggetti
 *
 * Disponibile su devACADEMY.it
 */

import java.time.LocalDate
import java.time.format.DateTimeFormatter

class ContoCorrente(nomeIntestatario:String,
                       indirizzoIntestatario: Indirizzo,
                            tipoConto:TipoConto=TipoConto.FILIALE) {

    private val importi=mutableListOf<Double>()

    private val intestatario=nomeIntestatario
    private val indirizzo=indirizzoIntestatario

    private val tipo=tipoConto

    private val formatter =DateTimeFormatter.ofPattern("dd/MM/yyyy")
    private val creazione=LocalDate.now()

    fun aggiungiImporto(nuovo:Double)
    {
        importi.add(nuovo)
    }

    fun calcolaSaldo():Double
    {
        return importi.sum()
    }

    fun stampaDescrizione()
    {
        println("Conto intestato a $intestatario")
        println("Residente in ${indirizzo.indirizzoConCivico}, ${indirizzo.citta}")
        println("Conto aperto il ${creazione.format(formatter)}")
        when(tipo)
        {
            TipoConto.ON_LINE -> println("Conto ON-LINE")
            TipoConto.FILIALE -> println("Conto presso filiale")
        }
        println("Saldo attuale = ${calcolaSaldo()}")

    }
}