/*
 * Screencast 
 * Kotlin: Programmazione Orientata agli Oggetti
 *
 * Disponibile su devACADEMY.it
 */

fun main(args: Array<String>)
{
    val conto=ContoCorrente("Giulio Rossi",
                                Indirizzo("Roma", "Via dei Cedri, 1000",
                                                                "00100"),
                                TipoConto.ON_LINE)

    //conto.intestatario="Giulio Rossi"

    conto.aggiungiImporto(1000.0)
    conto.aggiungiImporto(-250.0)
    conto.aggiungiImporto(-300.0)

    conto.stampaDescrizione()
}