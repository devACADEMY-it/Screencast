/*
 * Screencast 
 * Kotlin: Programmazione Orientata agli Oggetti
 *
 * Disponibile su devACADEMY.it
 */

enum class TipoConto {
    ON_LINE, FILIALE
}