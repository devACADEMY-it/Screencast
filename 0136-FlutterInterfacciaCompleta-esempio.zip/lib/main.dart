/*
 * Screencast 
 * Flutter: creazione di un'interfaccia
 *
 * Disponibile su devACADEMY.it
 */

import 'package:flutter/material.dart';
import 'package:flutter_app_gui/SecondaPagina.dart';
import 'package:flutter_app_gui/actions.dart';
import 'package:flutter_app_gui/drawer.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter GUI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'Flutter GUI'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: createActions(context),
      ),
      body: Center(
        child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Prima pagina dell\'app',
              style: Theme.of(context).textTheme.display1,
            ),
          ],
        ),
      ),
      drawer: createDrawer(context),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          // codice apertura seconda pagina
          Navigator.push(context, MaterialPageRoute(builder: (context)=>SecondaPagina()));
        },
        tooltip: 'Nuova pagina',
        child: Icon(Icons.add),
      ),
    );
  }
}