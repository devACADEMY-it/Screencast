/*
 * Screencast 
 * Flutter: creazione di un'interfaccia
 *
 * Disponibile su devACADEMY.it
 */

import 'package:flutter/material.dart';

createActions(BuildContext context){
    return[
            IconButton(
                icon: Icon(Icons.add),
                onPressed: (){
                   // apertura della finestra di dialogo
                   showDialog(
                      context:context,
                      builder: (BuildContext context){
                          return AlertDialog(
                               title: Text("Messaggio per l'utente"),
                               content: Text("Questo è il mio messaggio"),
                               actions: <Widget>[
                                  FlatButton(
                                      child: Text('Annulla'),
                                      onPressed: (){
                                         Navigator.pop(context);
                                      },
                                  ),
                                 FlatButton(
                                   child: Text('Continua'),
                                   onPressed: (){
                                     Navigator.pop(context);
                                   },
                                 ),
                               ]
                          );
                      }
                   );
                },
            ),
            PopupMenuButton(itemBuilder: (BuildContext context){
                return [
                    PopupMenuItem(child: FlatButton(
                      child: Text('Invia una notifica'),
                      onPressed: null,
                )),
                PopupMenuItem(child: FlatButton(
                    child: Text('Cancella i dati'),
                    onPressed: null,
                )),
                ];
            }),

    ];
}