/*
 * Screencast 
 * Flutter: creazione di un'interfaccia
 *
 * Disponibile su devACADEMY.it
 */

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SecondaPagina extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Seconda pagina"),
      ),
      body: Center(
        child: RaisedButton(
          onPressed: () {
            Navigator.pop(context);
          },
          child: Text('Clicca qui per tornare alla PRIMA!'),
        ),
      ),
    );
  }
}