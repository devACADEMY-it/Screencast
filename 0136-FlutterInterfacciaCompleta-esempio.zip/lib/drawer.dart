/*
 * Screencast 
 * Flutter: creazione di un'interfaccia
 *
 * Disponibile su devACADEMY.it
 */

import 'package:flutter/material.dart';

createDrawer(BuildContext context){
  return Drawer(
      child: ListView(
         padding: EdgeInsets.zero,
         children:<Widget>[
            DrawerHeader(
               decoration: BoxDecoration(
                  color: Colors.blue,
               ),
            ),
           ListTile(
              title: Text('Voce 1'),
              onTap:(){
                // Operazioni
              }
           ),
           ListTile(
               title: Text('Voce 2 (con chiusura)'),
               onTap:(){
                 // Operazioni
                 Navigator.pop(context);
               }
           ),
         ]
      )
  );
}