struct Operazione{
    descrizione: String,
    valore: f32
}

fn main(){
    let mut operazioni:Vec<Operazione>=Vec::new();
    operazioni.push(Operazione{descrizione: String::from("Accredito dello stipendio"), valore: 1850.0});
    operazioni.push(Operazione{descrizione: String::from("Pagamento benzina"), valore: -50.0});
    operazioni.push(Operazione{descrizione: String::from("Prelievo contanti"), valore: -150.0});
    
    let mut totale:f32= 0.0;
    
    for i in operazioni.iter(){
        println!("{}: {} euro", i.descrizione,i.valore);
        totale+=i.valore;
    }
    
     println!("Saldo totale: {} euro", totale);
    
    
}