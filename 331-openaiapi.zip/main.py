from openai import OpenAI
client=OpenAI()

domanda=input("Cosa vuoi sapere?")
completion=client.chat.completions.create(
  model="gpt-3.5-turbo",
  messages=[
    {"role":"user","content":domanda}
  ]
)

risposta=completion.choices[0].message.content
print()
print(domanda)
print(risposta)