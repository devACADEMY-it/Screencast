/*
 * Screencast
 * Java HTTP client: ricevere e trasmettere oggetti JSON
 *
 * Disponibile su devACADEMY.it
 */

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;
import java.util.ArrayList;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

class Log{
	String categoria;
	String messaggio;

	Log(String categoria, String messaggio){
		this.categoria=categoria;
		this.messaggio=messaggio;
	}
}

class Risposta{
	String uri;
}

class GestioneLog{
	private Gson gson=new GsonBuilder().create();
	private HttpClient client=HttpClient.newHttpClient();
	private String URL="https://api.myjson.com";

	private ArrayList<String> log_salvati=new ArrayList<String>();

	public String salvaLog(String categoria, String messaggio) {
		Log l=new Log(categoria, messaggio);
		HttpRequest req=HttpRequest.newBuilder()
							.uri(URI.create(URL+"/bins"))
							  .setHeader("Content-Type", "application/json")
							    .POST(BodyPublishers.ofString(gson.toJson(l)))
							      .build();
		try {
			HttpResponse<?> response=client.send(req, HttpResponse.BodyHandlers.ofString());
			if (response.statusCode()==201) {
				Risposta risposta=gson.fromJson(response.body().toString(),
							Risposta.class);
				log_salvati.add(risposta.uri);
				return risposta.uri;
			}
		} catch (IOException e) {
			return null;
		} catch (InterruptedException e) {
			return null;
		}
		return null;
	}

	public void stampaLista() {
		log_salvati.stream().forEach(System.out::println);
	}

	public Log scaricaLog(String uri) {
		HttpRequest req=HttpRequest.newBuilder()
							.uri(URI.create(uri))
							.setHeader("Content-Type", "application/json")
								.build();
		try {
			HttpResponse response=client.send(req,
					          HttpResponse.BodyHandlers.ofString());
			if (response.statusCode()==200)
			{
				Log messaggio =gson.fromJson(response.body().toString(),
									Log.class);
				return messaggio;
			}
		} catch (IOException e) {
			return null;
		} catch (InterruptedException e) {
			return null;
		}
		return null;
	}


}

public class Esempio {

	public static void main(String[] args) {
		GestioneLog logmanager=new GestioneLog();
		/*logmanager.salvaLog("INFO", "Prima prova con successo!");
		logmanager.salvaLog("AUTH", "PASSWORD ERRATA utente pippo2000");
		logmanager.salvaLog("ERROR", "Problema salvataggio file");
		logmanager.salvaLog("INFO", "Ultimo log salvato");

		logmanager.stampaLista();*/
		Log messaggio=logmanager.scaricaLog("https://api.myjson.com/bins/1enfq8");
		System.out.println(messaggio.categoria);
		System.out.println(messaggio.messaggio);

	}

}