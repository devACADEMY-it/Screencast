package main

import "fmt"

func main() {
	
	var valori[5] int
	valori[0]=56
	valori[3]=71
	fmt.Println(valori)
    fmt.Println(len(valori))
	
	inizializzato:=[6]int{24,12,5,60,88,90}
	fmt.Println("Array inizializzato ... ", inizializzato)
	
	fmt.Println()
	
	for x:=0; x<len(inizializzato);x++ {
		fmt.Println("--> ", inizializzato[x])
	} 
	
	fmt.Println()
	
	var multidim[2][3][2] int
	
	multidim[0][1][1]=5
	multidim[1][1][0]=6
	multidim[0][2][1]=7
	multidim[1][2][1]=8
	fmt.Println("Array multidimensionale 2 X 3 X 2... ", multidim)
	
	
}