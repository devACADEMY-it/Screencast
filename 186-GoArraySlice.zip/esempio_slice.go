package main

import "fmt"

func main() {
	
	slice := make([]int, 4)
    slice[0]=12
	slice[1]=45
	slice[2]=38
	
	slice=append(slice, 18)
	fmt.Println("slice ... ", slice)
	fmt.Println("lunghezza ... ", len(slice))
	
	fmt.Println( slice[2:4] )
	fmt.Println( slice[2:] )
	fmt.Println( slice[:4] )
	
	
	
	
	
	
	
	
}