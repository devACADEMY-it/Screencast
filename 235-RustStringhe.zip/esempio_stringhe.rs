fn main() {
    let nome:&str = "Paolo";
    let cognome:&str = "Rossi";
    
    println!("Ciao, mi chiamo {} {}", nome, cognome);
    
    println!("Il mio nome è lungo {} caratteri", nome.len());
    
    let mut nome_lungo=String::new();
    nome_lungo.push_str("Angelo");
    nome_lungo.push_str(" Maria");
    nome_lungo.push_str(" Carmelo");
    
    println!("Ciao, mi chiamo {} {}", nome_lungo, cognome);
    
    nome_lungo=nome_lungo.replace("Carmelo", "Alessio");
    println!("Ciao, mi chiamo {} {}", nome_lungo, cognome);
    
    let dati="Enzo,Bianchi,Roma,diploma";
    for porzione in dati.split(","){
        println!("> {}", porzione)
    }
    
    let porzioni:Vec<&str>=dati.split(",").collect();
    println!("nome = {}", porzioni[0]);
    println!("cognome = {}", porzioni[1]);
    println!("città = {}", porzioni[2]);
    println!("titolo di studio = {}", porzioni[3]);
    
    println!("nome lungo = {}", nome_lungo);
    println!("porzione di nome_lungo da 3 a 6 = {}", &nome_lungo[3..6]);
    println!("porzione di nome_lungo da 3 in poi = {}", &nome_lungo[3..]);
    println!("porzione di nome_lungo fino a 6 = {}", &nome_lungo[..6]);
    
    for c in nome_lungo.chars(){
        println!("> {}", c);
    }
    
    println!("Un solo carattere {}", nome_lungo.chars().nth(3).unwrap());
    
}