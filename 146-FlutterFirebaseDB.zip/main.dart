/*
 * Screencast 
 * Flutter e firebase: realizziamo un'app contatore
 *
 * Disponibile su devACADEMY.it
 */

import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

void main () => runApp(MaterialApp(home:CounterHomePage(),
                      debugShowCheckedModeBanner: false));

class CounterHomePage extends StatefulWidget {

  @override
  State<StatefulWidget> createState() => _CounterHomePageState();
}

class _CounterHomePageState extends State<CounterHomePage>{
  int _counter=0;
  final contatore=FirebaseDatabase.instance.reference().child('contatore');

  @override
  void initState() {
    super.initState();
    contatore.once().then(
        (sp){
          setState(
              (){
                 _counter=sp.value;
              }
          );
        }
    );
  }

  void _changeCounter(int value){
    setState((){
      if (value>0 || (value<0 && _counter>0)) {
        _counter += value;
        contatore.set(_counter);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Contatore in Flutter"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.display4,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(
                  margin: const EdgeInsets.only(right: 10.0),
                  child: RaisedButton(
                    onPressed: () => _changeCounter(-1),
                    child: const Text('-', style: TextStyle(fontSize: 25)),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.only(left: 10.0),
                  child: RaisedButton(
                    onPressed: () => _changeCounter(1),
                    child: const Text('+', style: TextStyle(fontSize: 25)),
                  ),
                ),
              ],
            ),
            FlatButton(
              onPressed: () => {

                setState(
                        (){_counter=0;
                           contatore.set(0);
                    }
                )
              },
              child: const Text('RESET', style: TextStyle(fontSize: 18)),
            ),
          ],
        ),
      )
      ,
    );
  }
}