#include <stdio.h>

struct esame{
   float orale;
   float scritto;
};


int main(void) {
  /*struct esame storia;
  storia.orale=10;
  storia.scritto=7;*/

  struct esame storia={4,5};
  printf("Scritto=%f\n", storia.scritto);
  printf("Orale=%f\n", storia.orale);
  
  if (storia.orale>=6 && storia.scritto>=6){
  printf("Il voto finale dell'esame è %f\n", (storia.orale+storia.scritto)/2);
  printf("L'esame è stato superato\n");}
  else if (storia.orale<6 ^ storia.scritto<6)
  {
    printf("L'esame NON è stato superato sebbene un voto sia sufficiente\n");
  }
  else
    printf("L'esame NON è stato superato e non ci sono voti sufficienti\n");
  return 0;
}