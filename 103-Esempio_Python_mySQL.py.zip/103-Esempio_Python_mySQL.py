#
# Screencast 
# Python: integrare database MySQL nelle applicazioni
#
# Disponibile su devACADEMY.it
#
 
import mysql.connector
import datetime

conn=mysql.connector.connect(user='root', password='', database='anagrafe')
inserimento="""INSERT INTO persone (nome, cognome, citta, data_nascita)
VALUES (%(nome)s, %(cognome)s, %(citta)s, %(data_nascita)s)"""

parametri={'nome':'Ivan',
           'cognome':'Bianchi',
           'citta':'Bari',
           'data_nascita':datetime.date(1985, 3, 25)}

cursor=conn.cursor()

query="""SELECT nome, cognome, citta, YEAR(now())-YEAR(data_nascita) as eta
FROM persone WHERE YEAR(now())-YEAR(data_nascita) BETWEEN %s AND %s
ORDER BY eta DESC"""

#cursor.execute(inserimento, parametri)
#id=cursor.lastrowid
cursor.execute(query, ('30','40'))

#print("Nuovo record con id={}".format(id))

for (nome, cognome, citta, eta) in cursor:
      print('{} {}, nato a {}, di anni {}'.format(nome,cognome,citta,eta))

cursor.close()
conn.close()
