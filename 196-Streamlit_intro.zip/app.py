import streamlit as st
import pandas as pd

st.title("Primo grafico in Streamlit")
st.subheader("Prima prova di Streamlit")

dati=pd.DataFrame(
{
	'mese': ['gen','feb','mar','apr','mag','giu'],
	'valore': [120,71,88,45,104,98]
})
#print(dati)

st.area_chart(dati)