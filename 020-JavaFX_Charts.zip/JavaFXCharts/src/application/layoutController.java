/*
 * Screencast
 * JavaFX: grafici per l'interfaccia utente
 *
 * Disponibile su devACADEMY.it
 */

package application;

import javafx.fxml.FXML;
import javafx.geometry.Side;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.AreaChart;

import javafx.scene.chart.BarChart;

public class layoutController {
	@FXML
	private AreaChart<String, Number> areaChart;
	@FXML
	private BarChart<String, Number> barChart;
	@FXML
	private LineChart<String, Number> lineChart;

	@FXML
	private NumberAxis yAxis;

	@FXML
	private void initialize()
	{
		XYChart.Series<String, Number> valori=new XYChart.Series<String, Number>();
		valori.setName("Incassi");
		valori.getData().add(new XYChart.Data<String, Number>("Gen", 12635));
		valori.getData().add(new XYChart.Data<String, Number>("Feb", 4789));
		valori.getData().add(new XYChart.Data<String, Number>("Mar", 8196));
		valori.getData().add(new XYChart.Data<String, Number>("Apr", 7165));
		valori.getData().add(new XYChart.Data<String, Number>("Mag", 11293));
		valori.getData().add(new XYChart.Data<String, Number>("Giu", 7899));

		XYChart.Series<String, Number> valori2=new XYChart.Series<String, Number>();
		valori2.setName("Alunni presenti");
		valori2.getData().add(new XYChart.Data<String, Number>("Lun", 16));
		valori2.getData().add(new XYChart.Data<String, Number>("Mar", 14));
		valori2.getData().add(new XYChart.Data<String, Number>("Mer", 14));
		valori2.getData().add(new XYChart.Data<String, Number>("Gio", 15));
		valori2.getData().add(new XYChart.Data<String, Number>("Ven", 16));

		XYChart.Series<String, Number> valori3=new XYChart.Series<String, Number>();
		valori3.setName("Incidenti");
		valori3.getData().add(new XYChart.Data<String, Number>("2014", 8));
		valori3.getData().add(new XYChart.Data<String, Number>("2015", 12));
		valori3.getData().add(new XYChart.Data<String, Number>("2016", 9));

		XYChart.Series<String, Number> valori4=new XYChart.Series<String, Number>();
		valori4.setName("Incidenti 2");
		valori4.getData().add(new XYChart.Data<String, Number>("2014", 9));
		valori4.getData().add(new XYChart.Data<String, Number>("2015", 11));
		valori4.getData().add(new XYChart.Data<String, Number>("2016", 8));


		areaChart.getData().add(valori);

		barChart.setHorizontalGridLinesVisible(true);
		barChart.setVerticalGridLinesVisible(false);

		barChart.setLegendVisible(false);
		barChart.getData().add(valori2);

		yAxis.setAutoRanging(false);
		yAxis.setLowerBound(7);
		yAxis.setUpperBound(14);
		yAxis.setTickUnit(3);

		lineChart.setLegendSide(Side.TOP);
		lineChart.getData().addAll(valori3,valori4);


	}


}
