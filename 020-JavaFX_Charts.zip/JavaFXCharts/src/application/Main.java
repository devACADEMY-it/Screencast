/*
 * Screencast
 * JavaFX: grafici per l'interfaccia utente
 *
 * Disponibile su devACADEMY.it
 */

package application;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class Main extends Application {
	@Override
	public void start(Stage stage) {

		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("layout.fxml"));
			Scene scene = new Scene(root);

	        stage.setTitle("Grafici in JavaFX");
	        stage.setScene(scene);
	        stage.show();
		} catch (IOException e) {
		}


	}

	public static void main(String[] args) {
		launch(args);
	}
}
