/*
 
	Screencast	
	Typescript, la nuova generazione di Javascript

	Disponibile su devACADEMY.it
	
*/

class Materia{
	private materia:string;
	private voto:number;
	
	constructor(materia:string, voto:number)
	{
		this.materia=materia;
		this.voto=voto;
	}
	
	leggiVoto():string
	{
		return `${this.voto}/30`;
	}
	
	get descrizione():string
	{
		return `${this.leggiVoto()} (${this.materia})`
	}
	
}

let libretto_universitario:Array<Materia>=[
	new Materia("Analisi Matematica I",21),
	new Materia("Analisi Matematica II",26),
	new Materia("Chimica",28)
]

for (let e of libretto_universitario)
	console.log(e.descrizione)

/*interface Materia{
	materia:string,
	voto:number	
}

let libretto_universitario:Array<Materia>=[
	{materia:"Analisi Matematica I", voto:21},
	{materia:"Analisi Matematica II", voto:23},
	{materia:"Chimica", voto:25}
]

for (let e of libretto_universitario)
	console.log(`${e.voto}/30 (${e.materia})`)*/


/*var messaggio:string="Ciao mondo!";
console.log(messaggio);*/