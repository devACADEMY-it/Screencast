import java.util.Arrays;
import java.util.Collection;
import java.util.stream.*;

public class Main {

    public static void main(String[] args) {
            Collection<String> fattoria = Arrays.asList("cane", "gatto", "topo", "pecora", "gallo", "tacchino");
            Stream<String> stream_fattoria = fattoria.stream();
            System.out.println("Quanti animali ci sono? "+stream_fattoria.count());
    }
}
