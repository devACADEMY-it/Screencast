#!/bin/bash

versioni=( '3.10' '3.8' )
for v in ${versioni[@]}
do 
    echo "Prova su Python "${v}
    docker build -t versioni_python  --build-arg versione=${v} . > /dev/null
    docker run versioni_python &> /dev/null
    if [[ $? -eq 0 ]]
    then
	    echo -e "\n---> In Python "${v}" funziona"
    else
	    echo -e "\n---> In Python "${v}" NON funziona"
    fi    
    echo -e "     ------------------------------\n"
done
