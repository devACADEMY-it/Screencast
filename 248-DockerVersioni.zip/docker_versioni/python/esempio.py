numeri=[3, 7, 12, 15, 20, 19, 24, 22]

for n in numeri:
    match n%2:
        case 0:
            print(f'{n} è PARI')
        case 1:
            print(f'{n} è DISPARI')
