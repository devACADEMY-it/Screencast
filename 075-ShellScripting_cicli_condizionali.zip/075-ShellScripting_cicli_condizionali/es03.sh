#!/bin/bash

if [ $# -le 0 ]
then
	echo "Errore: necessario un argomento numerico"
	exit 1
fi

for ((x=1;x<=10;x++ ))
do
	valore=$(($1*$x))
	echo "$1 X $x = $valore"
done
