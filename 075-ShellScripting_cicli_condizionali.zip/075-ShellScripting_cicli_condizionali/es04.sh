#!/bin/bash
while :
do
	read risp
	if [[ risp -eq 0 ]]
	then
		break
	fi
	somma=$((somma+risp))
done
echo "Somma: $somma"
