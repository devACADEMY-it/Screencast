#!/bin/bash

quanti=0

while [[ quanti -lt 5 ]]
do
	read risp
	if [[ risp -eq 0 ]]
	then
		break
	fi
	somma=$((somma+risp))
	quanti=$((quanti+1))
done
echo "Somma: $somma"
