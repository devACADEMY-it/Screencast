#!/bin/bash

for i in 12 20 40 8
do
	somma=$((somma+i))
done
echo $somma
