#!/bin/bash

echo "Immettere età:"
read eta

if [ $eta -lt 6 ]
then
	echo "Biglietto gratuito"
elif [ $eta -ge 6 -a $eta -le 15 ]
then
	echo "Biglietto ridotto (classe A): 8 euro"
elif [ $eta -ge 65 ]
then
	echo "Biglietto ridotto (classe B): 12 euro"
else
	echo "Biglietto standard: 15 euro"
fi
