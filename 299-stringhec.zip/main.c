#include <stdio.h>

int main () {
   char carattere='A';
   printf("Differenza G-A = %u\n", 'G' - 'A');
   printf("q - 32 = %c\n", 'q' - 32);
   printf("M + 32 = %c\n", 'M' + 32);

   char saluto[10];
   saluto[0]='C';
   saluto[1]='i';
   saluto[2]='a';
   saluto[3]='o';
   saluto[4]='\0';
   printf("Il nostro saluto: %s\n", saluto);

   char altro_saluto[]="Buonasera";
   printf("Un altro saluto: %s\n", altro_saluto);
   return 0;
}