<?php

require __DIR__ . '/vendor/autoload.php';

use Twig\Environment;
use Twig\Loader\FilesystemLoader;
use Twig\Extra\Intl\IntlExtension;

$file_loader=new FilesystemLoader(__DIR__.'/tmpl');
$twig=new Environment($file_loader);
$twig->addExtension(new IntlExtension());

$contabilita = [
    [
        'id'   => '1',
        'nr'   => '121',
        'data'         =>  '2020-08-25',
        'cliente' => 'Rossi Alberto',
        'importo' => 131.00,
    ],
    [
        'id'   => '2',
        'nr'   => '122',
        'data'         =>  '2020-08-25',
        'cliente' => 'Ferramenta Verdi',
        'importo' => 812.50,
    ],
    [
        'id'   => '3',
        'nr'   => '123',
        'data'         =>  '2020-08-26',
        'cliente' => 'Elena Bianchi',
        'importo' => 345.75,
    ],
    [
        'id'   => '4',
        'nr'   => '124',
        'data'         =>  '2020-08-27',
        'cliente' => 'Macelleria Gialli',
        'importo' => 78.25,
    ]
];

echo $twig->render('template.twig',['contabilita' => $contabilita]);
?>
