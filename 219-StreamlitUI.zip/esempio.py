import streamlit as st
from datetime import datetime
import json

st.title("Che ne pensi dei nostri negozi?")

nominativo=st.text_input("Chi sei?")
commento=st.text_area("Dacci il tuo parere")

scelta=st.sidebar.selectbox("Quale negozio hai visitato?", 
options=['Milano', 'Torino', 'Firenze', 'Roma', 'Napoli'])

voto=st.slider('Che voto ci dai?', min_value=0, max_value=10)
data=st.date_input("Quando ci hai visitato?", datetime(2000,1,1))

if st.button("Invia"):
    st.info("Grazie di averci aiutato")
    risposte={
	   "nominativo": nominativo,
	   "commento": commento,
	   "scelta": scelta,
	   "voto": voto,
	   "data": datetime.strftime(data, '%Y-%m-%d')
	}
    risposte
    with open('salvataggio.json', 'w') as f:
       json.dump(risposte, f)
	
