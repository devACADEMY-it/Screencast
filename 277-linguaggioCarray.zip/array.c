#include <stdio.h>
 
int main () {

   int numeri[10];
   int i;
   
   for (i=0; i<10; i++){
   	 numeri[i]=i*5;
   }
   
   for (i=0; i<10; i++){
   	 printf("In posizione %d il numero vale ... %d\n", i, numeri[i]);
   }
   
   
   return 0;
   
}