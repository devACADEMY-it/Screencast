package main

import (
    "fmt"
    "time"
)

func main() {
    d,_ :=time.Parse("02/01/2006","22/12/2008")
    fmt.Println(d)
    
    s:=d.Format("02 Jan 2006")
    fmt.Println(s)

    ora,_ := time.Parse("02/01/2006 15:04", "22/12/2008 18:32")
    fmt.Println(ora)

    due_ore_dopo:=ora.Add(time.Hour*2)
    fmt.Println(due_ore_dopo)

    inizio:=time.Date(2008,12,22,0,0,0,0,time.UTC)
    fine:=time.Date(2009,01,14,0,0,0,0,time.UTC)
    diff:=fine.Sub(inizio)
    fmt.Printf("Quanto tempo? %v\n", diff)
    fmt.Printf("Quanto tempo (in giorni)? %f\n", diff.Hours()/24)
}








