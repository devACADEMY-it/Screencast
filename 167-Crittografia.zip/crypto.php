<!--
 * Screencast 
 * Crittografare dati: dai concetti teorici all'uso pratico
 *
 * Disponibile su devACADEMY.it
-->
 
<?php

$messaggio="Messaggio segreto per te";
$algo="aes-128-gcm";
$password="topolino";

if (in_array($algo, openssl_get_cipher_methods())){
	$iv_pos=openssl_cipher_iv_length($algo);
	$iv=openssl_random_pseudo_bytes($iv_pos);
	$cifrato=openssl_encrypt($messaggio, $algo, $password, $options=0, $iv, $tag);
	echo $cifrato."\n\n";
	$messaggio_decifrato=openssl_decrypt($cifrato, $algo, $password, $options=0, $iv, $tag);
	echo $messaggio_decifrato;
}

?>