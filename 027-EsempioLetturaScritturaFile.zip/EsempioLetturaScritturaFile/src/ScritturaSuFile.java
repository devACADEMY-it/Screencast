/*
 * Screencast
 * Leggere e scrivere file di testo in Java
 *
 * Disponibile su devACADEMY.it
 */

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class ScritturaSuFile {
	public static void main(String[] args)
	{
		String nome="Nuovo.txt";

		try(BufferedWriter bw=Files.newBufferedWriter(Paths.get(nome), StandardOpenOption.CREATE,
					StandardOpenOption.APPEND))
		{
			for (int i=0; i<20; i++)
			{
				bw.write("Iterazione n. "+i);
				bw.newLine();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}