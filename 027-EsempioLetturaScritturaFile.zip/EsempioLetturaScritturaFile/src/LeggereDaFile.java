/*
 * Screencast
 * Leggere e scrivere file di testo in Java
 *
 * Disponibile su devACADEMY.it
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class LeggereDaFile {
	public static void main(String[] args) {
		String nome="persone.txt";

		try(BufferedReader br=Files.newBufferedReader(Paths.get(nome)))
		{
			String riga=null;
			while((riga=br.readLine())!=null)
				System.out.println(riga);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

}