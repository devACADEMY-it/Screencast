<?php
	$nomi=["Alessia", "Simona", "Samuele", "Elena", "Silvia", "Francesco"];
	$cognomi=["Rossi", "Neri", "Bianchi", "Marroni", "Gialli"];
	
	$nome_caso=$nomi[array_rand($nomi)];
	$cognome_caso=$cognomi[array_rand($cognomi)];
	$eta_caso=rand(18,99);
	
	//echo "$nome_caso $cognome_caso di anni $eta_caso";
	
	$persona_caso=["nome"=>$nome_caso, 
	               "cognome"=>$cognome_caso, 
				   "eta"=>$eta_caso];
	//echo json_encode($persona_caso);
	
	$inizio=strtotime("2001-01-01");
	$fine=strtotime("2003-12-31");
	$a_caso=rand($inizio, $fine);
	$data=date('Y-m-d H:i:s', $a_caso);
	echo $data
	
?>