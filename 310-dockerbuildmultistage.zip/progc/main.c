#include <stdio.h>

int main()
{
    printf("Ciao mondo!\n");
    return 0;
}
