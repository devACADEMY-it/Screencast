#!/bin/bash

echo Primo addendo
read op1
echo Secondo addendo
read op2

echo $(( op1+op2 ))
