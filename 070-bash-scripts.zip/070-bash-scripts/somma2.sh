#!/bin/bash

echo Programma $0 con PID $$
echo =============================
echo Immessi $# argomenti .... $@
echo Sommo i primi due

echo Risultato: $(( $1+$2 ))
