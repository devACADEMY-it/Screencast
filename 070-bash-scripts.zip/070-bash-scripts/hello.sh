#!/bin/bash

# Questo è un commento
echo Ciao Mondo!
