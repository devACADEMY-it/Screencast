  #!/bin/bash
  
  mionome=Luca
 
  comando=ec 
  ${comando}ho Ciao ${mionome}
