package com.example.demo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.demo.model.Temperature;

public interface TemperatureRepository extends MongoRepository<Temperature, String>{
   
}
