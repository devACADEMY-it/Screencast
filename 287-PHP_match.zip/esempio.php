<?php

function non_riconosciuto(){
    return "NON SO COSA FARE!!";
}

echo "Di che colore è il semaforo?\n";
$semaforo=strtoupper(chop(fgets(STDIN)));

//$semaforo="VRDE";
$cosa_fare=match($semaforo){
    'ROSSO' => "Fermati!!",
    'GIALLO' => 'Rallenta per fermarti!',
    'VERDE' => 'Puoi passare!',
    default =>  non_riconosciuto()
};

echo $cosa_fare."\n";