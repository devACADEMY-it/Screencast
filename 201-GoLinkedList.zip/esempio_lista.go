package main

import "fmt"

var inizio *Notizia
var fine *Notizia

type Notizia struct{
	succ* Notizia
	prec* Notizia
	titolo string
}

func aggiungiElemento(titolo string){
	n:=Notizia{titolo:titolo}
	if inizio==nil{
		inizio=&n
		fine=&n
	} else {
		n.prec=fine
		fine.succ=&n
		fine=&n
	}
}

func main(){
	aggiungiElemento("Nuovo libro di X")
	aggiungiElemento("Nuovo film di Y")
	aggiungiElemento("Nato il figlio di V")
	aggiungiElemento("Z ha vinto il premio K")
	aggiungiElemento("L ha vinto il campionato")
	
	tmp:=inizio
	for tmp!=nil{
		fmt.Println(tmp.titolo)
		tmp=tmp.succ
	}
	
	fmt.Println("Ora al contrario")
	
	tmp2:=fine
	for tmp2!=nil{
		fmt.Println(tmp2.titolo)
		tmp2=tmp2.prec
	}
}





