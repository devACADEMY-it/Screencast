/*
 * Screencast
 * Java: elaborare dati con le Stream API
 *
 * Disponibile su devACADEMY.it
 */

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Main {

	public static void main(String[] args) {

		//Stream<String> s=Stream.of("Nicola", "Eva", "Paolo", "Alessandro", "Sara");

		List<String> lista=Arrays.asList("Nicola", "Eva", "Paolo", "Alessandro", "Sara");

		Stream<String> s=lista.stream();

		System.out.println(s.count());

		System.out.println("\n");

		lista.stream().forEach( tmp -> System.out.println(tmp));

		System.out.println("\n");
		// in Java 7

		for (String tmp: lista)
			System.out.println(tmp);

		System.out.println("\n");

		lista.stream()
			.sorted()
			.forEach( tmp -> System.out.println(tmp));

		System.out.println("\n");
		/*
		// In Java 7

		Collections.sort(lista);
		for (String tmp: lista)
			System.out.println(tmp); */

		lista.stream()
			.sorted()
			.limit(2)
			.forEach( tmp -> System.out.println(tmp));

		System.out.println("\n");
		/*
		// In Java 7

		Collections.sort(lista);
		for (int i=0; i<2; i++)
			System.out.println(lista.get(i)); */

		lista.stream()
			.filter(tmp -> tmp.length()>=5)
			.sorted()
			.limit(2)
			.forEach(tmp -> System.out.println(tmp));

	}
}