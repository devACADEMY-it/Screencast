<?php
$dbserver="db";
$username="dockerdev";
$password="topolino";
$database="azienda";

$conn=new mysqli($dbserver, $username, $password, $database);
if ($conn->connect_error){
   die("Connessione FALLITA!");
}
if ($result=$conn->query("SELECT * FROM introiti")){
  echo "<ul>";
  foreach ($result->fetch_all(MYSQLI_ASSOC) as $riga){
     echo "<li>".$riga["centro"]." ".number_format($riga["incasso"],2,",",".")." euro";
  }
  echo "</ul>";
}
?>
