<?php
$dbserver="db";
$username="dockerdev";
$password="topolino";

$conn=new mysqli($dbserver, $username, $password);
if ($conn->connect_error){
   die("Connessione FALLITA!");
}
echo "Connessione RIUSCITA"
?>
