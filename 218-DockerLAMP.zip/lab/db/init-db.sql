USE azienda;
CREATE TABLE introiti(
	id INT AUTO_INCREMENT PRIMARY KEY,
	centro VARCHAR(5) NOT NULL,
	incasso FLOAT
);

INSERT INTO introiti (centro, incasso) VALUES ('TO001', 100);
INSERT INTO introiti (centro, incasso) VALUES ('TO002', 250);
INSERT INTO introiti (centro, incasso) VALUES ('TO001', 100);
INSERT INTO introiti (centro, incasso) VALUES ('NA001', 50);
INSERT INTO introiti (centro, incasso) VALUES ('NA001', 200);
INSERT INTO introiti (centro, incasso) VALUES ('NA002', 100);
INSERT INTO introiti (centro, incasso) VALUES ('RM001', 100);
INSERT INTO introiti (centro, incasso) VALUES ('RM001', 250);
