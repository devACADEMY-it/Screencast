const Validator = require('jsonschema').Validator
const v = new Validator()

const schema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://example.com/studente.schema.json",
  "title": "Studente",
  "description": "Lo schema di un generico oggetto Studente",
  "type": "object",
  
  "properties":{
     "nome":{
         "description":"il nome dello studente",
         "type": "string"
     },
     "media":{
         "description":"media dei voti",
         "type": "number",
         "minimum":0,
         "maximum":10
     },
     "eta":{
         "description":"età dello studente",
         "type": "integer",
         "minimum":18
     },
     "email":{
        "description":"contatti email dello studente",
        "type":"array",
        "items":{
            "type":"string"
        },
        "minItems": 1,
        "uniqueItems": true
     }
  },
  "required":["nome","media"]
}

oggetto={
	"nome":"Valeria Gialli",
	"media": "8.2"
}

console.log(v.validate(oggetto, schema))
