import eel
from random import randint

eel.init('www')

@eel.expose
def numero_casuale():
    return randint(1,100)

eel.start('index.html', mode="edge")