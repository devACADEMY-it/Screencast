package main

import (
  "fmt"
)

type Figura interface{
   calcola_area() float64
}

type Rettangolo struct{
  base, altezza float64
}

type Quadrato struct{
  lato float64
}

type Triangolo struct{
  base, altezza float64
}

func (f Triangolo) calcola_area() float64{
   return f.base*f.altezza/2
}

func (f Rettangolo) calcola_area() float64{
   return f.base*f.altezza
}

func (f Quadrato) calcola_area() float64{
   return f.lato*f.lato
}

func calcola(f Figura) float64{
   return f.calcola_area()
}

func main(){
 rettangolo:=Rettangolo{base:5, altezza: 6}
 quadrato:=Quadrato{lato: 6}
 triangolo:=Triangolo{base:5, altezza: 6}
 
 fmt.Println("Area del rettangolo: ", calcola(rettangolo))
 fmt.Println("Area del triangolo: ", calcola(triangolo))
 fmt.Println("Area del quadrato: ", calcola(quadrato))
}








