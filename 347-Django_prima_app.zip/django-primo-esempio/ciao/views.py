from django.shortcuts import render
from django.http import HttpResponse

def saluto(request):
    return HttpResponse("Ciao a tutti!!")
