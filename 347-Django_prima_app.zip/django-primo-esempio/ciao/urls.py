from django.urls import path

from . import views

urlpatterns=[
    path("ciaoooo",views.saluto,name="saluto")
]