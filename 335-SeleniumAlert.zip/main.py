from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

driver=webdriver.Chrome()
driver.get("http://localhost")

try:
    WebDriverWait(driver, 3).until(EC.alert_is_present())
    alert=driver.switch_to.alert
    print("Il messaggio nell'alert è: "+alert.text)
    input("Cliccare INVIO per chiudere")
    alert.accept()
except TimeoutException:
    print("Timeout scattato!")
    

driver.close()