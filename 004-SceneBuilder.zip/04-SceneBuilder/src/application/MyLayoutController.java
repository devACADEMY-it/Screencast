package application;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;

import javafx.event.ActionEvent;

public class MyLayoutController {
	@FXML
	private TextField nomeUtente;

	@FXML
	public void pulsanteCliccato(ActionEvent event) {
		
		String saluto="Ciao "+nomeUtente.getText()+"!";
		Alert alert=new Alert(AlertType.INFORMATION);
		alert.setHeaderText(null);
		alert.setTitle("Saluto");
		alert.setContentText(saluto);
		alert.showAndWait();
		
		nomeUtente.clear();
	}
}
