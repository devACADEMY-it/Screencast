<!--

	Screencast
	Monolog: libreria PHP per messaggi di log su file e database

	Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
   <link rel="stylesheet" type="text/css" href="stile_db.css"/>
</head>
<body>
<?php
	require_once 'vendor/autoload.php';
	use Monolog\Logger;
	//use Monolog\Handler\StreamHandler;
	use MySQLHandler\MySQLHandler;

	$log=new Logger('Tabellina');
	//$log->pushHandler(new StreamHandler('log_tab/tabellina.log', Logger::INFO));
	$conn='mysql:host=localhost;dbname=applicazione';
	$pdo=new PDO($conn, 'monolog', 'logger');

	$mysqlHandler=new MySQLHandler($pdo, "log", array('utente', 'contesto'), \Monolog\Logger::DEBUG);
	$log->pushHandler($mysqlHandler);

	if (!(array_key_exists('num',$_GET) && is_numeric($_GET['num'])))
	{
		$log->addError("Parametro non valido", array('utente'=>'admin', 'contesto'=>'corso PHP'));
		//$log->error("Parametro non valido", ['utente'=>'admin', 'contesto'=>'corso PHP']);
		die("Errore...il parametro num deve essere un numero!");
	}
	$log->addInfo("Parametro valido", array('utente'=>'admin', 'contesto'=>'corso PHP'));
	//$log->info("Parametro valido");
	$numero=round($_GET['num']);
?>
<div id="centrale">
<table>
<?php

for($i=1; $i<=10; $i++)
{ ?>
	<tr>
	    <?php
		   $log->addDebug("Iterazione n. $i", array('utente'=>'admin', 'contesto'=>'corso PHP'));
			/*$log->debug("Iterazione n. $i");*/
			?>
		<td class="sx"><?php echo "$i X $numero";?></td>
		<td class="dx"><?php echo $i*$numero ?></td>
	</tr>

<?php } ?>
</table>
</div>
</body>
</html>