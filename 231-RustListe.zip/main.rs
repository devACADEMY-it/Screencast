fn main() {
    let mut a=[5,6,7,8,9,10,11];
    let mut v=vec![5,6,7,8,9,10,11];
    let s=&a[3..6];
    println!("Un array = {:?}",a);
    println!("Un vettore = {:?}",v);
    println!("Uno slice  = {:?}",s);

    a[2]=999;
    println!("Un array dopo modifica= {:?}",a);

    v.push(999);
    v[3]=555;
    println!("Vettore modificato {:?}", v);

    println!("\nStampiamo l'array");
    for el in a.iter(){
      println!("Valore = {}", el);
    }

    println!("\nStampiamo il vettore");
    for el in v.iter(){
      println!("Valore = {}", el);
    }
}
