#include <stdio.h>
#include <string.h>

int main(void) {

  char stringa1[20]="Ciao mondo!";
  
  printf("Lunghezza della stringa: %i\n", strlen(stringa1));

  char parola1[10]="alba";
  char parola2[10]="albania";

  printf("Confronto tra %s e %s = %i\n", parola1, parola2, strcmp(parola1, parola2));
  printf("Confronto tra %s e %s = %i\n", parola1, parola1, strcmp(parola1, parola1));
  printf("Confronto tra %s e %s = %i\n", parola2, parola1, strcmp(parola2, parola1));

  char frase[50]="Il mondo è vario";
  char datrovare[]="mondo";

  printf("Ricerca nella stringa = %s\n", strstr(frase, datrovare));

  if (strstr(frase, datrovare) == NULL)
  {
    printf("La parola non è stata trovata nella stringa\n", strstr(frase, datrovare));
  }
  else
  {
    printf("Parola trovata!\n");
  }
  return 0;
}