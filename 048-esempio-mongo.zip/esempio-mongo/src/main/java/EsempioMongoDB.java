/*
 * Screencast
 * Integrare MongoDB in un'applicazione Java
 *
 * Disponibile su devACADEMY.it
 */

import java.util.Arrays;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class EsempioMongoDB {

	public static void main(String[] args) {
		MongoClient client=new MongoClient("localhost", 27017);

		MongoDatabase db=client.getDatabase("centro_formazione");

		MongoCollection<Document> collection=db.getCollection("studenti");

		Document studente1=new Document();
		studente1.put("nome", "Enzo");
		studente1.put("cognome", "Rossi");

		Document studente2=new Document();
		studente2.put("nome", "Valentina");
		studente2.put("cognome", "Bianchi");

		Document studente3=new Document();
		studente3.put("nome", "Luigi");
		studente3.put("cognome", "Neri");

		//collection.insertMany(Arrays.asList(studente1, studente2, studente3));

		System.out.println(collection.count());

		//collection.insertOne(studente1);

		client.close();



	}

}
