/*
 * Screencast
 * Retrofit e JSON per accedere a servizi REST
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.retrofit_json;

import java.io.IOException;

import com.google.gson.annotations.SerializedName;

import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

class Proverbio
{
	private String proverbio;

	Proverbio(String proverbio)
	{
		this.proverbio=proverbio;
	}

	public String getProverbio() {
		return proverbio;
	}

	public void setProverbio(String proverbio) {
		this.proverbio = proverbio;
	}

}

class Risposta
{
	@SerializedName("uri")
	private String indirizzo;

	public String getIndirizzo() {
		return indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public String getId()
	{
		int indice = indirizzo.lastIndexOf("/");
		return indirizzo.substring(indice);
	}
}

interface JsonService
{
	@GET("/bins/{id}")
	Call<Proverbio> recuperaStringa(@Path(value="id") String id);

	@POST("/bins")
	Call<Risposta> salvaProverbio(@Body Proverbio nuovo);
}

public class App
{
    public static void main( String[] args )
    {

    	String url = "https://api.myjson.com/";

    	Retrofit retrofit = new Retrofit.Builder()
    							.baseUrl(url)
    							.addConverterFactory(GsonConverterFactory.create())
    							.build();

    	JsonService service = retrofit.create(JsonService.class);

    	Proverbio nuovoProverbio = new Proverbio("Gallina vecchia fa buon brodo");

    	try {
			Response<Risposta> post= service.salvaProverbio(nuovoProverbio).execute();

			Risposta o = post.body();
			System.out.println("Indirizzo dell'oggetto salvato");
			System.out.println(o.getIndirizzo());

			String idSalvato = o.getId();

			Response<Proverbio> res=service.recuperaStringa(idSalvato).execute();

			Proverbio proverbio = res.body();
			System.out.println("\nNuovo proverbio salvato:");
			System.out.println(proverbio.getProverbio());


		} catch (IOException e) {
			e.printStackTrace();
		}

    }
}
