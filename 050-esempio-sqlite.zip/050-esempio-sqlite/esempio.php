<!--

	Screencast
	Come integrare un database Sqlite in un'applicazione PHP

	Disponibile su devACADEMY.it

-->

<?php

	$db=new PDO("sqlite:dbesempio.db");
	$res=$db->query("SELECT count(*) as quanti FROM persone");
	$r=$res->fetch();
	echo $r["quanti"];

	echo "<br><br>";

	$res=$db->query("SELECT * FROM persone LIMIT 15");
	$persone=$res->fetchAll(PDO::FETCH_ASSOC);
	foreach($persone as $p)
	{
		echo $p['nome']." ".$p['cognome']."<br>";
	}

	$db_mem=new PDO("sqlite::memory:");
	$db_mem->exec("CREATE TABLE ordini (id INTEGER PRIMARY KEY AUTOINCREMENT, importo REAL)");
	$stmt=$db_mem->prepare("INSERT INTO ordini(importo) VALUES (:importo)");
	$importo=60;
	$stmt->bindParam(":importo", $importo, PDO::PARAM_STR);
	$stmt->execute();
	$stmt->bindParam(":importo", $importo, PDO::PARAM_STR);
	$stmt->execute();
	$stmt->bindParam(":importo", $importo, PDO::PARAM_STR);
	$stmt->execute();

	$res=$db_mem->query("SELECT sum(importo) as totale FROM ordini");
	echo "<br><br>";
	echo $res->fetch()['totale'];

?>