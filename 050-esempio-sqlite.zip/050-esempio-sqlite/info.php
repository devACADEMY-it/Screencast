<!--

	Screencast
	Come integrare un database Sqlite in un'applicazione PHP

	Disponibile su devACADEMY.it

-->

<?php
	phpinfo();
?>