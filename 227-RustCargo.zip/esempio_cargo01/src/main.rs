mod saluto;
fn main() {
    println!("Hello, world!");
    saluto::offri_saluto();
}
