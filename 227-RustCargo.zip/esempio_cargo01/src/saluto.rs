pub fn offri_saluto(){
    println!("Saluto da MODULO...");
}
