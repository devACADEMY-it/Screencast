mod caso;

fn main() {
    println!("Generazione numeri casuali...");
    caso::genera()
}
