use rand::Rng;

pub fn genera(){
  let mut rng= rand::thread_rng();

  let n1:u8=rng.gen();
  let n2:u16=rng.gen();

  println!("Casuale u8: {}", n1);
  println!("Casuale u16: {}", n2);

}
