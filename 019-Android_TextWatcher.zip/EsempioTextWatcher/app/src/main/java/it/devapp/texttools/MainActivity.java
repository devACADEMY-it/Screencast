/*
 * Screencast
 * Android: controllare l'input con TextWatcher
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.texttools;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = (EditText) findViewById(R.id.piva);
        editText.addTextChangedListener(pivaWatcher);
    }

    private TextWatcher pivaWatcher=new TextWatcher()
    {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            Log.d("TEXTWATCHER_BEFORE",s+": "+count+" caratteri a partire da "+start+" verranno sostituiti con altri "+after);

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

             if (!s.toString().matches("[0-9]{11}"))
                 editText.setBackgroundColor(Color.parseColor("#FF0000"));
             else
                 editText.setBackgroundColor(Color.parseColor("#00FF00"));

            Log.d("TEXTWATCHER_ON",s+": "+before+" caratteri a partire da "+start+" sono stati sostituiti con altri "+count);

        }

        @Override
        public void afterTextChanged(Editable editable) {
            Log.d("TEXTWATCHER_AFTER",editable.toString());

        }
    };

}