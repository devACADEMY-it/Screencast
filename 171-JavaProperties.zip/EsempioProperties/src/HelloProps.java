/*
 * Screencast 
 * Java: configurare un proprio programma con le Properties
 *
 * Disponibile su devACADEMY.it
 */

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

public class HelloProps {

	public static void main(String[] args) {
		try {
			FileInputStream ins=new FileInputStream("config.props");
			Properties props=new Properties();
			props.load(ins);
			System.out.println(props.get("autore"));
			props.setProperty("versione", "2.0");
			FileWriter out=new FileWriter("D:\\config\\config.props");
			props.store(out, "Ultima versione della configurazione");
			System.out.println("Fine");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}

}