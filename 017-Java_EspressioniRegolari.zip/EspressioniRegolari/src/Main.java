/*
 * Screencast
 * Java: introduzione alle espressioni regolari
 *
 * Disponibile su devACADEMY.it
 */

 import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) {

		    // regex1= "[0-9]{9,}"
		    String numero1="339123456";

		    String numero2="339-123456";

		    String regexCellulare="[0-9]{3}-{0,1}[0-9]{6,}";

		    String[] numeriDaValidare=new String[]
		    		{
		    				"339123456",
		    				"339-123456",
		    				"339--123456",
		    				"33-9123456",
		    				"545453",
		    				"3391fr456"
		    		};

		    for (String s: numeriDaValidare)
		    {
		    	System.out.println(s);
		    	if (s.matches(regexCellulare))
		    	{
		    		System.out.println(s+" è valido");
		    	}
		    	else
		    		System.out.println(s+" NON è valido");
		    	System.out.println();
		    }

			/*
			 *  [A-Z] = A, B, C, ...
			 *  [cfg]
			 *  [^cfg]
			 *
			 *  [A-Z]*
			 *  [A-Z]+
			 *  [A-Z]{2}
			 *  [0-9]{2,6}
			 *  [a-z]{2,}
			 * */
			/*String targa="AB123VV";

			String regex="[A-Z]{2}[0-9]{3}[A-Z]{2}";

			if (Pattern.matches(regex, targa))
				System.out.println("La stringa rappresenta una targa");
			else
				System.out.println("La stringa NON rappresenta una targa");*/


	}

}
