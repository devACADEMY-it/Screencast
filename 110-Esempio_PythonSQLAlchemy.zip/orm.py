#
# Screencast
# Python e SQLAlchemy: soluzione completa per database
#
# Disponibile su devACADEMY.it
#

from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

class Persona(Base):
  __tablename__='persone'
  id=Column(Integer, primary_key=True)
  nome=Column(String)
  cognome=Column(String)
  eta=Column(Integer)
  citta=Column(String)


engine = create_engine('sqlite:///D:\dbesempio.db')
session = sessionmaker()
session.configure(bind=engine)
Base.metadata.create_all(engine)
s=session()

r = s.query(Persona).filter_by(cognome='Marroni')[0:5]
for x in r:
 print(x.cognome)