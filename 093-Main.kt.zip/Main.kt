/*
 * Screencast
 * Iniziamo a programmare con Kotlin
 *
 * Disponibile su devACADEMY.it
 */

fun creaTabellina(tabellinaDel: Int): ArrayList<Int> {
    val tabellina= arrayListOf<Int>()

    (1..10).forEach { tabellina.add(it*tabellinaDel) }

    return tabellina

}

fun stampaTabellina(tabellinaDel: Int)
{
    for (n in 1..10)
        println("$n X $tabellinaDel = ${tabellinaDel*n}")
}

fun main(args: Array<String>)
{
    print("Immettere un numero >> ")
    val tabellinaDel= readLine()!!.toInt()

    //stampaTabellina(tabellinaDel)

    val tab=creaTabellina(tabellinaDel)

    tab.forEach { println(it) }

}