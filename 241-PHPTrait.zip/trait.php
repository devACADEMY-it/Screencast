<?php

  trait FunzioniComuni{
	  
	  private $messaggio="Questa è una funzione in comune ma chiamata da un oggetto di ";
	  
	  private function in_comune($dove){
		  echo $this->messaggio.$dove."\n";
	  }
  }
  
  class A {
	  
	  use FunzioniComuni;
	  public function nome(){
		  echo "Sono la classe A\n";
		  $this->in_comune("A");
	  }
  }
  
  class B {
	  
	  use FunzioniComuni;
	  public function nome(){
		  echo "Sono la classe B\n";
		  $this->in_comune("B");
	  }
  }
  
  $a=new A();
  $a->nome();
  //$a->in_comune("A");
  
  $b=new B();
  $b->nome();
  //$b->in_comune("B");
  
  
  
  
  
  
?>