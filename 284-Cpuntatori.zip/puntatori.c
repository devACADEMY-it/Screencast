#include <stdio.h>
int main() {
	int valore=10;
	int* rife_a_valore=&valore;
	
    printf("Contenuto di valore = %d\n", valore);
    printf("Indirizzo di valore = %p\n", &valore);
    printf("Contenuto di rife_a_valore = %p\n\n", rife_a_valore);
    
    *rife_a_valore=555;
    printf("Contenuto di valore = %d\n\n", valore);
    
    int valori[]={1,2,3,4,5};
    printf("Terzo elemento = %d\n", valori[2]);
    
    int* rife_a_array=valori;
    printf("Puntatore a array = %d\n", *rife_a_array);
    
    *(rife_a_array+2)=555;
    printf("Terzo elemento = %d\n", valori[2]);
	return 0;
}



