record Studente(String nome, String matricola, int eta){
    Studente{
        System.out.println("nome ---> "+nome);
        System.out.println("matricola ---> "+matricola);
        System.out.println("eta ---> "+eta);

        if (nome.length()<2){
            System.out.println("Attenzione: nome non accettabile");
            throw new IllegalArgumentException();
        }

    }

    boolean maggiorenne(){
        return eta>=18;
    }

    String nomecompleto(){
        return nome+" (matricola:"+matricola +")";
    }
};

public class Main{
    public static void main(String[] args){
        Studente allievo=new Studente("Gianni Rossi", "A12345", 19);
        if (allievo.maggiorenne())
            System.out.println(allievo.nome()+" è maggiorenne");
        else
            System.out.println(allievo.nome()+" è minorenne");
        System.out.println("Creato: "+allievo.nomecompleto());
    }
}