<!--

	Screencast
	RedBeanPHP: un ORM per gestire database

	Disponibile su devACADEMY.it

-->

<?php

$url="localhost";
$username="root";
$password="";
$db="statistiche";

?>