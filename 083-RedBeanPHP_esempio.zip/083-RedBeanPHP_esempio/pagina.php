<!--

	Screencast
	RedBeanPHP: un ORM per gestire database

	Disponibile su devACADEMY.it

-->

<?php
	require_once('DbManager.php');
	$pagina=basename($_SERVER['PHP_SELF']);
	aggiornaStatistica($pagina);
?>

<!DOCTYPE HTML>
	<html>
		<head>
		   <title>Esempi PHP</title>
		</head>
	<body>
		<h1>Benvenuti!!</h1>
	</body>
</html>