<!--

	Screencast
	RedBeanPHP: un ORM per gestire database

	Disponibile su devACADEMY.it

-->

<?php
	require_once 'config_db.php';
	require_once 'rb-mysql.php';

	R::setup("mysql:host=$url; dbname=$db",
				$username,
					$password);

	function caricaStatistiche()
	{
		return R::findAll('statistiche');
	}

	function aggiornaStatistica($pagina)
	{
	  $stat=R::findOne('statistiche',
						'pagina=?',
							[$pagina]);
	  if (count($stat)>0)
	  {
		  $stat->visite++;
		  R::store($stat);
	  }
	  else
	  {
		  $nuova_statistica=R::dispense('statistiche');
		  $nuova_statistica->pagina=$pagina;
		  $nuova_statistica->visite=1;
		  $id=R::store($nuova_statistica);
	  }

	}
?>