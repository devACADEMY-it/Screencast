<!--

	Screencast
	RedBeanPHP: un ORM per gestire database

	Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
   <link rel="stylesheet" type="text/css" href="stile_db.css"/>
</head>
<body>
<div id="centrale">
<table>
<?php
require_once('DbManager.php');

$stat=caricaStatistiche();

foreach($stat as $s)
{ ?>
	<tr>
		<td class="sx"><?php echo $s['pagina']?></td>
		<td class="dx"><?php echo $s['visite']?></td>
	</tr>

<?php } ?>
</table>
</div>
</body>
</html>