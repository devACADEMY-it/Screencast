/*
 * Screencast
 * LinkedList e ArrayList a confronto
 *
 * Disponibile su devACADEMY.it
 */

import java.util.Iterator;
import java.util.LinkedList;

public class Esempio01 {

	public static void main(String[] args) {
		LinkedList<String> ll=new LinkedList<>();
		ll.addLast("cane");
		ll.addLast("gatto");
		ll.addLast("topo");
		ll.addLast("asino");
		ll.addLast("gallo");

		Iterator<String> it=ll.iterator();

		while(it.hasNext())
		{
			System.out.println(it.next());
		}

		System.out.println();

        it=ll.descendingIterator();

		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}

}