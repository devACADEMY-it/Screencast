/*
 * Screencast
 * LinkedList e ArrayList a confronto
 *
 * Disponibile su devACADEMY.it
 */

import java.util.ArrayList;
import java.util.LinkedList;

public class Esempio02 {

	public static void main(String[] args) {

		long inizio, fine;

		int MAX=100000;

		ArrayList<Integer> arrayList;
		LinkedList<Integer> linkedList;

		arrayList=new ArrayList<Integer>();

		inizio=System.currentTimeMillis();
		for(int i=0;i<MAX;i++)
			arrayList.add(i);
		fine=System.currentTimeMillis();

		System.out.println("ArrayList ha impiegato per l'inserimento in coda "+(fine-inizio)+" ms.");

		linkedList=new LinkedList<Integer>();

		inizio=System.currentTimeMillis();
		for(int i=0;i<MAX;i++)
			linkedList.addLast(i);
		fine=System.currentTimeMillis();

		System.out.println("LinkedList ha impiegato per l'inserimento in coda "+(fine-inizio)+" ms.");

		System.out.println("\n");

		arrayList=new ArrayList<Integer>();

		inizio=System.currentTimeMillis();
		for(int i=0;i<MAX;i++)
			arrayList.add(0, i);
		fine=System.currentTimeMillis();

		System.out.println("ArrayList ha impiegato per l'inserimento in testa "+(fine-inizio)+" ms.");

		linkedList=new LinkedList<Integer>();

		inizio=System.currentTimeMillis();
		for(int i=0;i<MAX;i++)
			linkedList.addFirst(i);
		fine=System.currentTimeMillis();

		System.out.println("LinkedList ha impiegato per l'inserimento in testa "+(fine-inizio)+" ms.");
	}

}