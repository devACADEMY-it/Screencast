SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dati`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `andamento`
--

DROP TABLE IF EXISTS `andamento`;
CREATE TABLE IF NOT EXISTS `andamento` (
  `giorno` date NOT NULL,
  `prezzo` int(11) NOT NULL,
  PRIMARY KEY (`giorno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `andamento`
--

INSERT INTO `andamento` (`giorno`, `prezzo`) VALUES
('2020-01-07', 22),
('2020-01-08', 24),
('2020-01-09', 26),
('2020-01-10', 25),
('2020-01-13', 28),
('2020-01-14', 26),
('2020-01-15', 23),
('2020-01-16', 21),
('2020-01-17', 19),
('2020-01-20', 21),
('2020-01-21', 18),
('2020-01-22', 16),
('2020-01-23', 19),
('2020-01-24', 21),
('2020-01-27', 23),
('2020-01-28', 25),
('2020-01-29', 20),
('2020-01-30', 16),
('2020-01-31', 14);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
