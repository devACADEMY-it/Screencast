#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
  char* sorgente;
  char* destinazione;
  FILE *f_in, *f_out;
  unsigned int letti, scritti;
  unsigned char buffer[512];
  
   if (argc!=3){
     printf("Argomenti errati!");
     exit(EXIT_FAILURE);
   }

  sorgente=argv[1];
  destinazione=argv[2];

  f_in=fopen(sorgente, "rb");
  if (f_in==NULL){
    printf("File in input non disponibile!");
    exit(EXIT_FAILURE);
  }

  f_out=fopen(destinazione, "wb");
  if (f_out==NULL){
    printf("File in output non disponibile!");
    exit(EXIT_FAILURE);
  }

  do{
    letti=fread(buffer, 1, sizeof buffer, f_in);
    printf("Letti %d => ", letti);
    scritti=fwrite(buffer, 1, letti, f_out);
    printf("Scritti %d \n", scritti);
  }
  while(letti>0);
  fclose(f_out);
  fclose(f_in);
}