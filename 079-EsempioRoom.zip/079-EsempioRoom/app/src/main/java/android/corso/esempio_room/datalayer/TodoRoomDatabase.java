/*
 * Screencast
 * Android: gestire database SQLite con Room
 *
 * Disponibile su devACADEMY.it
 */

package android.corso.esempio_room.datalayer;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

@Database(entities={Todo.class}, version=1)
public abstract class TodoRoomDatabase extends RoomDatabase {
    private static TodoRoomDatabase INSTANCE;

    public abstract TodoDao todoModel();

    public static TodoRoomDatabase getDatabase(Context context)
    {
        if (INSTANCE==null)
            INSTANCE= Room.databaseBuilder(context.getApplicationContext(),
                    TodoRoomDatabase.class, "todo.db")
                    .allowMainThreadQueries()
                    .build();
        return INSTANCE;
    }


}