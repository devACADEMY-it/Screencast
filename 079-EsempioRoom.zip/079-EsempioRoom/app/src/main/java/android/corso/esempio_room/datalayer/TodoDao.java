/*
 * Screencast
 * Android: gestire database SQLite con Room
 *
 * Disponibile su devACADEMY.it
 */

package android.corso.esempio_room.datalayer;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;

import static android.arch.persistence.room.OnConflictStrategy.REPLACE;

@Dao
public interface TodoDao {

    @Insert(onConflict=REPLACE)
    void insertNote(Todo todo);

    @Query("SELECT * FROM Todo")
    List<Todo> loadAllTodos();

    @Query("DELETE FROM Todo")
    void deleteAll();

    @Delete
    void deleteNote(Todo todo);
}