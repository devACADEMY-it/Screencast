/*
 * Screencast
 * Android: gestire database SQLite con Room
 *
 * Disponibile su devACADEMY.it
 */

package android.corso.esempio_room.datalayer;

import android.app.Application;
import android.content.Context;

import java.util.ArrayList;
import java.util.List;

public class TodoRepository {

    private TodoDao dao;

    public TodoRepository(Application application)
    {
        Context context=application.getApplicationContext();
        TodoRoomDatabase db=TodoRoomDatabase.getDatabase(context);
        dao=db.todoModel();
    }


    public List<Todo> getTodoList() {
        return dao.loadAllTodos();
    }

    public void deleteAll() {
        dao.deleteAll();
    }

    public void delete(Todo todo) {
        dao.deleteNote(todo);
    }

    public void insert(Todo todo) {
        dao.insertNote(todo);
    }
}