/*
 * Screencast
 * Android: gestire database SQLite con Room
 *
 * Disponibile su devACADEMY.it
 */

package android.corso.esempio_room;

import android.content.Context;
import android.corso.esempio_room.datalayer.Todo;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.List;

public class TodoListAdapter extends RecyclerView.Adapter<TodoListAdapter.TodoViewHolder> {


    public TodoListAdapter(Context context) {

        inflater = LayoutInflater.from(context);
    }

    class TodoViewHolder extends RecyclerView.ViewHolder {
        private final TextView titleTextView;
        private final TextView descriptionTextView;
        private final ImageButton deleteButton;

        private TodoViewHolder(View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.txt_title);
            descriptionTextView = itemView.findViewById(R.id.txt_description);
            deleteButton =itemView.findViewById(R.id.btn_delete);
        }
    }

    private final LayoutInflater inflater;
    private List<Todo> todoList;

    @NonNull
    @Override
    public TodoListAdapter.TodoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = inflater.inflate(R.layout.row_layout, parent, false);
        return new TodoViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TodoListAdapter.TodoViewHolder holder, int position) {
        if (todoList != null) {
            Todo current = todoList.get(position);
            holder.titleTextView.setText(current.title);
            holder.descriptionTextView.setText(current.description);
            holder.deleteButton.setTag(current);
        } else {
            holder.titleTextView.setText("No title");
            holder.descriptionTextView.setText("No description");
        }
    }

    public void setList(List<Todo> list)
    {
        todoList=list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if (todoList != null)
            return todoList.size();
        else return 0;
    }
}