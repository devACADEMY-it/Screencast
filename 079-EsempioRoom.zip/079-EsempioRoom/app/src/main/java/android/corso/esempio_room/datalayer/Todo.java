/*
 * Screencast
 * Android: gestire database SQLite con Room
 *
 * Disponibile su devACADEMY.it
 */

package android.corso.esempio_room.datalayer;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

@Entity
public class Todo {

    @PrimaryKey(autoGenerate = true)
    @NonNull
    public long id;

    public String title;
    public String description;

    public Todo(String title, String description)
    {
        this.title=title;
        this.description=description;
    }
}