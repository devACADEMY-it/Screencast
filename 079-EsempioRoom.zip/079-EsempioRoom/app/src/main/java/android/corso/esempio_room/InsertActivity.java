/*
 * Screencast
 * Android: gestire database SQLite con Room
 *
 * Disponibile su devACADEMY.it
 */

package android.corso.esempio_room;

import android.app.Activity;
import android.corso.esempio_room.datalayer.Todo;
import android.corso.esempio_room.datalayer.TodoRepository;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

public class InsertActivity extends AppCompatActivity {

    private EditText txt_title;
    private EditText txt_description;

    private TodoRepository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        repository=new TodoRepository(getApplication());

        txt_title =(EditText) findViewById(R.id.txt_title);
        txt_description =(EditText) findViewById(R.id.txt_description);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.insert_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId())
        {
            case R.id.action_save:
                if (txt_title.length()>0)
                {
                    String stringTitle=txt_title.getText().toString();
                    String stringDescription=txt_description.getText().toString();

                    Todo todo=new Todo(stringTitle, stringDescription);

                    repository.insert(todo);
                    setResult(Activity.RESULT_OK);
                    finish();
                }
                else
                    Toast.makeText(this, R.string.toast_insert_error_message,
                            Toast.LENGTH_SHORT).show();

        }
        return false;
    }
}