/*
 * Screencast
 * Android: gestire database SQLite con Room
 *
 * Disponibile su devACADEMY.it
 */

package android.corso.esempio_room;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.corso.esempio_room.datalayer.Todo;
import android.corso.esempio_room.datalayer.TodoRepository;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private TodoListAdapter adapter=null;
    private TodoRepository repository;
    private RecyclerView recyclerView;

    public static final int INSERT_REQUEST=100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        repository=new TodoRepository(getApplication());

        recyclerView = findViewById(R.id.recyclerview);
        adapter=new TodoListAdapter(this);
        adapter.setList(repository.getTodoList());
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode==INSERT_REQUEST && resultCode== Activity.RESULT_OK)
        {
            adapter.setList(repository.getTodoList());
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId())
        {

            case R.id.action_new:
                Intent i=new Intent(this, InsertActivity.class);
                startActivityForResult(i, INSERT_REQUEST);
                break;

            case R.id.action_delete_all:
                repository.deleteAll();
                adapter.setList(null);



        }
        return false;
    }

    public void deleteRow(final View v)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this)
                .setMessage("Cancellare definitivamente la nota?")
                .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                               Todo todo= (Todo) v.getTag();
                               repository.delete(todo);
                               adapter.setList(repository.getTodoList());
                            }
                        }
                )
                .setNegativeButton("No", null);

        builder.show();
    }

}