from pywebio import start_server
from pywebio.output import put_table
from pywebio.input import input

def main():
    while True:
        domanda=input("Immetti un calcolo da fare...")
        try:
            risposta=eval(domanda)
        except:
            risposta='Domanda non valida!'
    
        put_table(
            [
                ['Domanda:', domanda],
                ['Risposta:', risposta]
            ]
        )

if __name__=='__main__':
    start_server(main, port=9000)