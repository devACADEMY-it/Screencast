package it.devapp.esempioservice;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import java.util.Timer;
import java.util.TimerTask;

public class MyService extends Service {

    private static final String TAG="Primo Service";
    private Timer timer=null;
    private static final int MAX_ESECUZIONI=5;
    private int contatore;

    @Override
    public void onCreate() {
        Log.d(TAG, "Service creato");
        timer=new Timer();
        contatore=1;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TAG, "Service avviato");

        timer.scheduleAtFixedRate(
                new TimerTask() {
                    @Override
                    public void run() {
                            Log.d(TAG, "iterazione n. "+contatore);
                            if (contatore++ == MAX_ESECUZIONI)
                                stopSelf();
                    }
                }, 1000, 2000
        );
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (timer==null)
        {
            timer.cancel();
        }
        Log.d(TAG, "Service distrutto");
    }

    @Override
    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
