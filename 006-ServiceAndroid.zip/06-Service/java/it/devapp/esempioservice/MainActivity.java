package it.devapp.esempioservice;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);}

    public void avviaService(View v)
    {
        startService(new Intent(MainActivity.this, MyService.class));
        Snackbar.make(v, "Service avviato", Snackbar.LENGTH_LONG).show();
    }

    public void fermaService(View v)
    {
        stopService(new Intent(MainActivity.this, MyService.class));
        Snackbar.make(v, "Service arrestato", Snackbar.LENGTH_LONG).show();
    }

}
