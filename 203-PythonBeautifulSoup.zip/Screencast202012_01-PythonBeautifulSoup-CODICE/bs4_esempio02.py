from bs4 import BeautifulSoup
testo_lungo = """
<div class="news">
  <div class="article">
   <h2 class="article-title">
    10 posti bellissimi per le vacanze
   </h2>
   <img height="40px" src="img1.png" width="40px"/>
   <div class="article-summary">
    <p>
     Parliamo delle più belle spiagge del Mediterraneo
    </p>
   </div>
  </div>
  <div class="article">
   <h2 class="article-title">
    Come cucinare la triglia
   </h2>
   <img height="40px" src="img2.png" width="40px"/>
   <div class="article-summary">
    <p>
     Ricette più facili con la triglia
    </p>
   </div>
  </div>
  <div class="article">
   <h2 class="article-title">
    Le isole più belle del mondo
   </h2>
   <img height="40px" src="img3.png" width="40px"/>
   <div class="article-summary">
    <p>
     Ecco le isole più affascinanti del mondo
    </p>
   </div>
  </div>
</div>
 """

soup=BeautifulSoup(testo_lungo)
titoli=[art.text.strip() for art in soup.select("h2")]
print(titoli)