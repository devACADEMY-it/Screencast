from bs4 import BeautifulSoup
testo = """
<div class="article">
   <h2 class="article-title">
    10 posti bellissimi per le vacanze
   </h2>
   <img height="40px" src="img1.png" width="40px"/>
   <div class="article-summary">
    <p>
     Parliamo delle più belle spiagge del Mediterraneo
    </p>
   </div>
</div>
 """

soup=BeautifulSoup(testo)
titolo=soup.select("div.article-summary p")[0].text.strip()
print(f"Titolo: {titolo}")
altezza_img=soup.select("div.article img")[0].get("height")
print(f"Altezza immagine: {altezza_img}")
sorgente_img=soup.select("div.article img")[0].get("src")
print(f"Sorgente immagine: {altezza_img}")