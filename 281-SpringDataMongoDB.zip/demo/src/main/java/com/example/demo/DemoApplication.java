package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;

@SpringBootApplication
@EnableMongoRepositories
public class DemoApplication implements CommandLineRunner {

	@Autowired
	StudentRepository classRepo;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Stiamo per creare i documenti");
		classRepo.save(new Student("Gino", "Rossi", 6));
		classRepo.save(new Student("Alessia", "Neri", 9));
		classRepo.save(new Student("Marta", "Verdi", 8));
		classRepo.save(new Student("Marco", "Bianchi", 7));
		System.out.println("Abbiamo creato "+classRepo.count()+" documenti");
	}

}
