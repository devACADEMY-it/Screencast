package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("students")
public class Student {
		
	   @Id
	   private String id;
	   
		private String name;
		private String surname;
		private int mark;
		
		public Student(String name, String surname, int mark) {
			super();
			this.name = name;
			this.surname = surname;
			this.mark = mark;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getSurname() {
			return surname;
		}

		public void setSurname(String surname) {
			this.surname = surname;
		}

		public int getMark() {
			return mark;
		}

		public void setMark(int mark) {
			this.mark = mark;
		}
		
}
