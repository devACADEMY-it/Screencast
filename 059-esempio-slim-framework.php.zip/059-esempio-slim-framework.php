<!--

	Screencast
	Introduzione a Slim Framework

	Disponibile su devACADEMY.it

-->

<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require 'vendor/autoload.php';

$app = new \Slim\App;

$app->get('/tabellina/{numero}', function (Request $request, Response $response) {
	// indirizzo/tabellina/8

	$numero=$request->getAttribute('numero');

	$tabellina="";

	for ($i=1; $i<=10; $i++)
		$tabellina.="$numero X $i = ".($i*$numero)."<br>";

	$response->getBody()->write($tabellina);

	return $response;

});

$app->get('/hello', function (Request $request, Response $response) {

    $response->getBody()->write("Ciao a tutti!!");

	return $response;

});

$app->run();
?>