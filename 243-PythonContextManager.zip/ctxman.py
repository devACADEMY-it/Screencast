"""with open('dati.txt') as f:
   print(f.read())"""

class EsecuzioneOperazioni:
   def __init__(self, context):
      self.context=context
      print(f"   COSTRUTTORE di EsecuzioneOperazioni")
	  
   def download(self):
      print(f"   ...stiamo scaricando i dati da {self.context.sorgente}")
	  
   def __del__(self):
      print("   CHIUSURA definitiva dell'oggetto")
	  
class RecuperoDati:
   def __init__(self, sorgente):
      self.sorgente=sorgente
      print(f"COSTRUTTORE: Recuperare dati da {sorgente}")

   def __enter__(self):
      print("ENTER: creazione del context")
      return EsecuzioneOperazioni(self)
   
   def __exit__(self, exc_type, exc_value, exc_tb):
      print("EXIT: uscita dal context")
	  
with RecuperoDati("www.fontechenonesiste.org") as dati:
   dati.download()