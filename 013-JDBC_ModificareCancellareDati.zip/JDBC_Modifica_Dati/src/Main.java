/*
 * Screencast
 * Java: salvare e cancellare dati in un database relazionale con JDBC
 *
 * Disponibile su devACADEMY.it
 */

public class Main {

	public static void main(String[] args)
	{
		String connectionString="jdbc:sqlite:dbesempio.db";

		try {
			Class.forName("org.sqlite.JDBC");
		} catch (ClassNotFoundException e) {
			System.exit(1);
		}

		DbManager db=new DbManager(connectionString);

		//Persona p=new Persona("Stefano", "Rossi", 34, "Parma");

		//db.inserisciPersona(p);

		boolean b=db.cancellaPersona(11);

		if (b)
			System.out.println("Cancellazione eseguita");
		else
			System.out.println("Cancellazione fallita");




	}

}


