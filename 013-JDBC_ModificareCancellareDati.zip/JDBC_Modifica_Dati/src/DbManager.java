/*
 * Screencast
 * Java: salvare e cancellare dati in un database relazionale con JDBC
 *
 * Disponibile su devACADEMY.it
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DbManager {

	private String connectionString;

	DbManager(String connectionString)
	{
		this.connectionString=connectionString;
	}

	public boolean cancellaPersona(int id)
	{
		Connection connection=null;

		try{
			connection=DriverManager.getConnection(connectionString);
			PreparedStatement stm=connection.prepareStatement(
					"DELETE FROM persone WHERE id=?");
			stm.setInt(1, id);

			int r=stm.executeUpdate();

			if (r>0)
				return true;
			return false;

		}
		catch (SQLException e) { /*** ****/}
		finally
		{
			try
			{
				if (connection!=null)
					connection.close();
			}
			catch (SQLException e) { /*** ****/}
		}
		return false;
	}

	List<Persona> recuperaElenco()
	{
		Connection connection=null;
		try {
				// 1. connessione
				connection=DriverManager.getConnection(connectionString);

				// 2. creazione dello Statement sulla connessione attiva
				Statement stm=connection.createStatement();

				// 3. esecuzione della query
				ResultSet rs=stm.executeQuery("SELECT * FROM persone");

				// 4. gestione del risultato
				Persona p=null;
				ArrayList<Persona> risultato=new ArrayList<Persona>();
				while(rs.next())
				{
					p=new Persona( rs.getInt("id"),
								   rs.getString("nome"),
							       rs.getString("cognome"),
							       rs.getInt("eta"),
							       rs.getString("citta")
							);
					risultato.add(p);
				}
				return risultato;
			}
			catch (SQLException e) { /** **/ }
			finally
			{
				// 5. chiusura della connessione
				if (connection!=null)
					try {
						connection.close();
					} catch (SQLException e) {

					}
			}

			return null;
	}

	public boolean inserisciPersona(Persona nuovo)
	{
		Connection connection=null;

		try{
			connection=DriverManager.getConnection(connectionString);
			PreparedStatement stm=connection.prepareStatement(
					"INSERT INTO persone (cognome, nome, eta, citta) VALUES (?,?,?,?)");
			stm.setString(1, nuovo.getCognome());
			stm.setString(2, nuovo.getNome());
			stm.setInt(3, nuovo.getEta());
			stm.setString(4, nuovo.getCitta());

			int r=stm.executeUpdate();

			ResultSet s=stm.getGeneratedKeys();
			if (s.next())
				nuovo.setId(s.getInt(1));

			if (r>0)
				return true;
			return false;

		}
		catch (SQLException e) { /*** ****/}
		finally
		{
			try
			{
				if (connection!=null)
					connection.close();
			}
			catch (SQLException e) { /*** ****/}
		}
		return false;
	}




}
