/*
 * Screencast
 * Java: salvare e cancellare dati in un database relazionale con JDBC
 *
 * Disponibile su devACADEMY.it
 */


public class Persona {

	private String nome;
	private String cognome;
	private String citta;
	private int eta;
	private int id;

	public Persona(String nome, String cognome, int eta, String citta)
	{
		this.nome=nome;
		this.cognome=cognome;
		this.citta=citta;
		this.eta=eta;
		id=-1;
	}

	public Persona(int id, String nome, String cognome, int eta, String citta)
	{
		this(nome, cognome, eta, citta);
		this.id=id;
	}

	@Override
	public String toString() {

		String s=nome+" "+cognome+", "+eta+" anni, nato a "+citta;
		if (id>0)
			s+=" (id="+id+")";
		return s;
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getCitta() {
		return citta;
	}
	public void setCitta(String citta) {
		this.citta = citta;
	}
	public int getEta() {
		return eta;
	}
	public void setEta(int eta) {
		this.eta = eta;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}


}
