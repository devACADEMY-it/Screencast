/*
 * Screencast
 * Java 10: novità per programmatori
 *
 * Disponibile su devACADEMY.it
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Main {

    public static void main(String[] args)
    {

        var nomi=new ArrayList<String>();
        nomi.add("Enzo");
        nomi.add("Roberto");
        nomi.add("Silvio");
        nomi.add("Alessandro");

        nomi.forEach(System.out::println);

        String unNome= nomi.get(0);

        System.out.println("\n====================\n");

        var copiaNomi= List.copyOf(nomi);

        copiaNomi.stream()
                 .filter(s->s.length()>6)
                 .forEach(System.out::println);

        //copiaNomi.add("Alberto");

        System.out.println("\n====================\n");

        var insiemeNomi=new TreeSet<String>(nomi);

        var copiaInsiemeNomi= Set.copyOf(insiemeNomi);

        copiaInsiemeNomi.stream()
                .filter(s->s.length()>6)
                .forEach(System.out::println);

    }
}