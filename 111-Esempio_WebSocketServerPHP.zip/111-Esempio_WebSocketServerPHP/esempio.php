<!--

	Screencast
	WebSocket: realizzare un server in PHP

	Disponibile su devACADEMY.it

-->

<?php

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

require __DIR__.'/vendor/autoload.php';

class EchoWeb implements MessageComponentInterface{
	public function __construct(){
		echo "Avviato il server...\n";
	}

	public function onOpen(ConnectionInterface $c){
		echo "iniziata connessione...\n";
	}

	public function onMessage(ConnectionInterface $c, $msg){
		$c->send("Mi hai scritto ".$msg."\n");
	}

	public function onClose(ConnectionInterface $c){
		echo "Connessione chiusa...\n";
	}

	public function onError(ConnectionInterface $c, \Exception $e){
		$c->close();
	}

}

$app = new Ratchet\App('localhost', 8080);
$app->route('/echo', new EchoWeb, array('*'));
$app->run();

?>