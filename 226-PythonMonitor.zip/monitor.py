import requests as r

def verifica_link(url):
    try:
         res=r.head(url)
         if res.status_code==200:
              print(f'Link {url} ===> OK')
         else:
              print(f'Link {url} ===> KO')
    except:
         print(f'Link {url} ===> ERRORE')

indirizzi=[
'http://localhost:8000/sport.html',
'http://localhost:8000/cronaca.html',
'localhost:8000/sport.html',
'http://localgjoierjgoiehost:8000/politica.html',
'http://localhost:8000/sport.html',
'http://localhost:8000/economia.html',
'http://localhost:8000/politica.html'
]

for i in indirizzi:
    verifica_link(i)