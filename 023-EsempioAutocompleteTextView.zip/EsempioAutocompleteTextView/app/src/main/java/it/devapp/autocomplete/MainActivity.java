/*
 * Screencast
 * AutoCompleteTextView in Android
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.autocomplete;

import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private AutoCompleteTextView textView;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> suggerimenti=new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        suggerimenti.add("Bianco");
        suggerimenti.add("Bianchi");
        suggerimenti.add("Bianchini");
        suggerimenti.add("Bianchetti");
        suggerimenti.add("Bianchinelli");

        adapter=new ArrayAdapter<String>(this, R.layout.row, R.id.text, suggerimenti)
        {
            @NonNull
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v=super.getView(position, convertView, parent);
                if (position%2==0)
                    v.setBackground(new ColorDrawable(0xFFCCCCCC));
                else
                    v.setBackground(new ColorDrawable(0xFFFFFFFF));
                return v;
            }
        };

        textView= (AutoCompleteTextView) findViewById(R.id.cognome);
        textView.setAdapter(adapter);

        textView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String s=((TextView)view.findViewById(R.id.text)).getText().toString();
                Toast.makeText(MainActivity.this, "Selezionato: "+s, Toast.LENGTH_LONG).show();
            }
        });
    }

}