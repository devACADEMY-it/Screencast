import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {

	public static void main(String[] args) 
	{
		String connectionString="jdbc:sqlite:dbesempio.db";
		
		try {
			Class.forName("org.sqlite.JDBC");
		} catch (ClassNotFoundException e) {
			System.exit(1);
		}
		
		Connection connection=null;
		
		try {
			connection=DriverManager.getConnection(connectionString);
			
			Statement stm=connection.createStatement();
			
			ResultSet rs=stm.executeQuery("SELECT * FROM persone");
			
			while(rs.next())
			{
				System.out.println(
								rs.getString("nome")+" "+
										rs.getString("cognome")+ " di anni "+
											rs.getInt("eta")+ " proveniente da "+
												rs.getString("citta")
						);
			}
			
			
			
		} catch (SQLException e) {
			
		}
		
		finally
		{
			if (connection!=null)
				try {
					connection.close();
				} catch (SQLException e) {
					
				}
		}
		
	}
	
}


