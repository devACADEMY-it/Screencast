/*
 * Screencast
 * Android: importare dati JSON in Realm
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.realmjsonesempio;

import android.app.Application;

import io.realm.Realm;
import io.realm.RealmConfiguration;

public class MyApplication extends Application {

    private static final String REALM_NAME = "archivio_citta";

    @Override
    public void onCreate() {
        super.onCreate();
        Realm.init(this);
        RealmConfiguration configuration=new RealmConfiguration.Builder()
                .name(REALM_NAME)
                .build();
        Realm.setDefaultConfiguration(configuration);

    }
}
