/*
 * Screencast
 * Android: importare dati JSON in Realm
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.realmjsonesempio;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import io.realm.Realm;
import io.realm.RealmAsyncTask;

public class MainActivity extends AppCompatActivity {

    private ListView lista;
    private CittaAdapter adapter;
    private Realm realm;
    private RequestQueue requestQueue;
    private RealmAsyncTask transaction;

    private Response.Listener<JSONArray> listener=new Response.Listener<JSONArray>() {
        @Override
        public void onResponse(final JSONArray response) {

            transaction=realm.executeTransactionAsync(new Realm.Transaction() {
                                              @Override
                                              public void execute(Realm realm) {
                                                  realm.createOrUpdateAllFromJson(Citta.class, response);
                                              }
                                          },
                    new Realm.Transaction.OnSuccess() {
                        @Override
                        public void onSuccess() {
                            adapter.updateData(realm.where(Citta.class).findAll());
                        }
                    });
        }
    };

    private Response.ErrorListener errorListener=new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        realm=Realm.getDefaultInstance();
        requestQueue=Volley.newRequestQueue(this);
        requestQueue.add(new JsonArrayRequest("http://devacademy.it/try/015-Realm_JSON_dati_esempio.json", listener, errorListener));

        lista= (ListView) findViewById(R.id.lista);

        adapter=new CittaAdapter(this, realm.where(Citta.class).findAll());
        lista.setAdapter(adapter);

    }

    @Override
    protected void onStop() {
        super.onStop();
        if (transaction!=null && !transaction.isCancelled())
            transaction.cancel();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        realm.close();
    }
}
