/*
 * Screencast
 * Android: importare dati JSON in Realm
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.realmjsonesempio;


import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class Citta extends RealmObject
{
    @PrimaryKey
    private String nome;
    private int abitanti;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getAbitanti() {
        return abitanti;
    }

    public void setAbitanti(int abitanti) {
        this.abitanti = abitanti;
    }

    @Override
    public String toString() {
        return nome+ " ("+abitanti+" ab.)";
    }
}