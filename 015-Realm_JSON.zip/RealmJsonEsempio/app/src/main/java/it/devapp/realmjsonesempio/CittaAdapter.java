/*
 * Screencast
 * Android: importare dati JSON in Realm
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.realmjsonesempio;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.TextView;

import io.realm.OrderedRealmCollection;
import io.realm.RealmBaseAdapter;

public class CittaAdapter extends RealmBaseAdapter<Citta> implements ListAdapter{

    private static class ViewHolder
    {
        TextView txt_title;
    }

    public CittaAdapter(@NonNull Context context, @Nullable OrderedRealmCollection<Citta> data) {
        super(context, data);
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder vh;
        if (view==null)
        {
            view= LayoutInflater.from(viewGroup.getContext()).inflate(android.R.layout.simple_list_item_1, null);
            vh=new ViewHolder();
            vh.txt_title= (TextView) view.findViewById(android.R.id.text1);
            view.setTag(vh);
        }
        else
            vh= (ViewHolder) view.getTag();

        Citta c=getItem(i);

        vh.txt_title.setText(c.toString());

        return view;
    }
}
