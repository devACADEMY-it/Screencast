from fastapi import FastAPI
from fastapi.responses import HTMLResponse

app=FastAPI()

@app.get("/saluto/", response_class=HTMLResponse)
async def greeting():
   return """
   <html>
     <head><title>Pagina di saluto</title></head>
     <body><h1>Ciao mondo! (in HTML)</h1></body>
   </html>
   """