/*
 * Screencast
 * Java e Android: eseguire test automatici con JUnit
 *
 * Disponibile su devACADEMY.it
 */


package devapp.it.esempiojunit;

import java.util.ArrayList;

public class Cassa {

	private ArrayList<Float> importi=new ArrayList<Float>();

	void inserisciValore(float nuovo)
	{
		if (nuovo<0)
			throw new IllegalArgumentException();
		importi.add(nuovo);
	}

	boolean aggiungiValore(float nuovo)
	{
		if (nuovo<0)
			return false;
		importi.add(nuovo);
		return true;
	}

	int numeroValori()
	{
		return importi.size();
	}

	float calcolaTotale()
	{
		float totale=0f;
		for (float f: importi)
			totale+=f;
		return totale;
	}

}