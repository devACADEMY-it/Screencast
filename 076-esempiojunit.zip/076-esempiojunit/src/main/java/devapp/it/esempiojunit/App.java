/*
 * Screencast
 * Java e Android: eseguire test automatici con JUnit
 *
 * Disponibile su devACADEMY.it
 */

package devapp.it.esempiojunit;


public class App
{
    public static void main( String[] args )
    {
        // codice del programma
    }
}