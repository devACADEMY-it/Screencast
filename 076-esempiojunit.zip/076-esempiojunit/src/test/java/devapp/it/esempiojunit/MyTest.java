/*
 * Screencast
 * Java e Android: eseguire test automatici con JUnit
 *
 * Disponibile su devACADEMY.it
 */

package devapp.it.esempiojunit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class MyTest {

	private Cassa c;

		public MyTest()
		{
			c=new Cassa();
			c.aggiungiValore(45);
			c.aggiungiValore(21);
			c.aggiungiValore(6);
		}

		@Test(expected=IllegalArgumentException.class)
		public void testInserimento()
		{
			c.inserisciValore(-8);
		}

		@Test
		public void testAggiuntaImporti()
		{
			assertEquals(3, c.numeroValori());
		}

		@Test
		public void testNuovoImportoCorretto()
		{
			assertTrue(c.aggiungiValore(45));
		}

		@Test
		public void testNuovoImportoNonCorretto()
		{
			assertFalse(c.aggiungiValore(-45));
		}

		@BeforeClass
		public static void inizializzazione()
		{
			System.out.println("Inizio dei test");
		}

		@AfterClass
		public static void conclusione()
		{
			System.out.println("Conclusione dei test");
		}

		@Before
		public void primaDiOgniTest()
		{
			System.out.println("Prima di ogni test");
		}

		@After
		public void dopoOgniTest()
		{
			System.out.println("dopo ogni test");
		}

}