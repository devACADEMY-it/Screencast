import streamlit as st
from random import randint, random

st.write("""
# Controlli Streamlit in un normale programma Python
Faremo un esempio con **numeri casuali**
""")

st.sidebar.header("Valori da regolare")

def genera():
   interi=st.sidebar.checkbox('Solo interi')
   numeri_da_generare=st.sidebar.slider('Quanti', 2, 10)
   minimo=st.sidebar.slider('Minimo', 0, 50)
   massimo=st.sidebar.slider('Massimo', 51, 100)
   if interi:
      dati=[randint(minimo,massimo) for i in range(0, numeri_da_generare)]
   else:
      dati=[random()*(massimo-minimo)+minimo for i in range(0, numeri_da_generare)]
   return dati

dati=genera()
st.write(dati)

st.write(f'Numeri generati: {len(dati)}')





