/*
 * Screencast 
 * Flutter: gestire lo stato dell'applicazione con gli StatefulWidget
 *
 * Disponibile su devACADEMY.it
 */

import 'package:flutter/material.dart';

void main () => runApp(MaterialApp(home:CounterHomePage()));

class CounterHomePage extends StatefulWidget {

  @override
  State<StatefulWidget> createState() => _CounterHomePageState();
}

  class _CounterHomePageState extends State<CounterHomePage>{
     int _counter=0;

     void _changeCounter(int value){
        setState((){
           if (value>0 || (value<0 && _counter>0))
             _counter+=value;
        });
     }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
           title: Text("Contatore in Flutter"),
        ),
        body: Center(
           child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                   '$_counter',
                   style: Theme.of(context).textTheme.display4,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      margin: const EdgeInsets.only(right: 10.0),
                      child: RaisedButton(
                         onPressed: () => _changeCounter(-1),
                         child: const Text('-', style: TextStyle(fontSize: 25)),
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(left: 10.0),
                      child: RaisedButton(
                        onPressed: () => _changeCounter(1),
                        child: const Text('+', style: TextStyle(fontSize: 25)),
                      ),
                    ),
                  ],
                ),
                FlatButton(
                   onPressed: () => {
                      setState(
                          (){
                             _counter=0;
                          }
                      )
                   },
                   child: const Text('RESET', style: TextStyle(fontSize: 18)),
                ),
              ],
           ),
        )
       ,
    );
  }

}