/*
 * Screencast
 * Intent impliciti in Android
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.esempiointentimpliciti;

import android.content.Intent;
import android.net.Uri;
import android.provider.AlarmClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void impostaTimer(View v)
    {
        Intent intent=new Intent(AlarmClock.ACTION_SET_TIMER);
        intent.putExtra(AlarmClock.EXTRA_MESSAGE, "Scaduto il timer");
        intent.putExtra(AlarmClock.EXTRA_LENGTH, 10);
        intent.putExtra(AlarmClock.EXTRA_SKIP_UI, true);

        if (intent.resolveActivity(getPackageManager())!=null)
            startActivity(intent);
    }

    public void chiama(View v)
    {
        Intent intent=new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:06123456"));

        if (intent.resolveActivity(getPackageManager())!=null)
            startActivity(intent);
    }

    public void apriMappa(View v)
    {
        Intent intent=new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("geo:45.070740, 7.684504?z=16"));

        if (intent.resolveActivity(getPackageManager())!=null)
            startActivity(intent);
    }

    public void apriURL(View v)
    {
        Uri pagina=Uri.parse("http://www.devapp.it");
        Intent intent=new Intent(Intent.ACTION_VIEW, pagina);

        if (intent.resolveActivity(getPackageManager())!=null)
            startActivity(intent);
    }



}
