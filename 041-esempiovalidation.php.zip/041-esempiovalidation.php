<!--

	Screencast
	PHP, verificare dati con Validation

	Disponibile su devACADEMY.it

-->

<?php
require 'vendor/autoload.php';

use Respect\Validation\Validator as v;

$numero = 45;
if (v::intVal()->validate($numero))
	echo "$numero: numero intero";
else
	echo "$numero: NON un numero intero";

echo "<br>";

if (v::intVal()->positive()->odd()->between(15,33)->validate(26))
	echo "$numero: positivo, dispari, compreso tra 15 e 33";
else
	echo "$numero: NON positivo, dispari, compreso tra 15 e 33";

echo "<br><br>";

//$stringa="JABCFDERTGFSS";
$stringa="857395734895789";

if (v::alnum()->validate($stringa))
	echo "$stringa alfanumerico";
else
	echo "$stringa NON alfanumerico";

echo "<br>";

if (v::alpha()->validate($stringa))
	echo "$stringa solo lettere";
else
	echo "$stringa NON solo lettere";

echo "<br>";

if (v::digit()->validate($stringa))
	echo "$stringa solo cifre";
else
	echo "$stringa NON solo cifre";

echo "<br>";

$codice="1234";
if (v::alnum()->noWhitespace()->length(4,8)->validate($codice))
	echo "$codice alfanumerico, senza spazi, lungo tra 4 e 8 caratteri";
else
	echo "$codice NON alfanumerico, senza spazi, lungo tra 4 e 8 caratteri";

echo "<br>";echo "<br>";

$cap="10136";
echo "$cap codice postale ? " . v::postalCode('IT')->validate($cap);
echo "<br>";

$email="io@miosito.it";
echo "$email indirizzo mail ? " . v::email()->validate($email);
echo "<br>";

$url="http://www.devacademy.it";
echo "$url indirizzo web ? " . v::url()->validate($url);

?>
