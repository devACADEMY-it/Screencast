/*
 * Screencast
 * Java: Stack e Queue
 *
 * Disponibile su devACADEMY.it
 */

import java.util.ArrayDeque;
import java.util.PriorityQueue;

public class Esempio {

	public static void main(String[] args) {
		ArrayDeque<String> lifo=new ArrayDeque<String>();
		lifo.addFirst("task 1");
		lifo.addFirst("task 2");
		lifo.addFirst("task 3");

		System.out.println(lifo.removeFirst());
		System.out.println(lifo.removeFirst());
		System.out.println(lifo.removeFirst());


		/*PriorityQueue<String> fifo=new PriorityQueue<String>();

		fifo.add("task 1");
		fifo.add("task 2");
		fifo.add("task 3");

		System.out.println("Inseriti "+fifo.size()+" elementi");

		System.out.println(fifo.remove());
		System.out.println(fifo.remove());
		System.out.println(fifo.remove());*/
	}

}