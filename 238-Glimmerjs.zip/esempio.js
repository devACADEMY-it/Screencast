
import Component, { hbs, tracked } from '@glimmerx/component';
import { on, action } from '@glimmerx/modifier';

export default class HelloWorld extends Component {
  @tracked count = 1;
  @tracked caso = 0;

  @action increment() {
    this.count++;
  }

  @action genera_caso() {
    this.caso=Math.random()*massimo.value;
  }

  static template = hbs`
    <h1>Welcome to the GlimmerX Playground!</h1>

    <input type="text" value="10" id="massimo" name="massimo"/>
    <p>You have clicked the button {{this.count}} times.</p>
    <p>Numero generato casualmente: {{this.caso}}.</p>

    <button {{on "click" this.increment}}>Click</button>
    <button {{on "click" this.genera_caso}}>Casuale</button>
  `;
}