/*
 * Screencast
 * Android: animazioni con ViewPropertyAnimator
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.animazioni;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView txt;
    private DisplayMetrics metrics;

    private void generaNumeri()
    {
        Random rand=new Random();

        int nuovo = rand.nextInt(49)+1;
        ((TextView) findViewById(R.id.txt1)).setText(Integer.toString(nuovo));
        nuovo = rand.nextInt(29)+1;
        ((TextView) findViewById(R.id.txt2)).setText(Integer.toString(nuovo));
        nuovo = rand.nextInt(29)+1;
        ((TextView) findViewById(R.id.txt3)).setText(Integer.toString(nuovo));
        nuovo = rand.nextInt(29)+1;
        ((TextView) findViewById(R.id.txt4)).setText(Integer.toString(nuovo));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);
        txt= (TextView) findViewById(R.id.res);

        generaNumeri();

        metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
    }

    public void traslaGiu(final View v)
    {
        v.animate().setDuration(1400).y(metrics.heightPixels)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        String numero=((TextView) v).getText().toString();
                        somma(numero);
                    }
                });
    }

    public void scompare(final View v)
    {
        v.animate().setDuration(1000).rotation(360).alpha(0f)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        String numero=((TextView) v).getText().toString();
                        somma(numero);
                    }
                });
    }

    public void traslaDX(final View v)
    {
        v.animate().setDuration(1500).rotation(-360).x(metrics.widthPixels)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        String numero=((TextView) v).getText().toString();
                        somma(numero);
                    }
                });
    }

    public void volavia(final View v)
    {
        v.animate().setDuration(1000).scaleY(6).alpha(0f).rotation(360).x(metrics.widthPixels)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        String numero=((TextView) v).getText().toString();
                        somma(numero);
                    }
                });
    }



    private void somma(String nuovo)
    {
        int risultato=Integer.parseInt(txt.getText().toString())+Integer.parseInt(nuovo);
        txt.setText(Integer.toString(risultato));
    }


}
