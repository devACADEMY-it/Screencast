module.exports = Object.freeze({
    NEWSAPI_KEY: 'INSERIRE PROPRIA API KEY'
});