const NewsAPI = require('newsapi')
const constants = require('./constants_list')
const newsapi = new NewsAPI(constants.NEWSAPI_KEY)

newsapi.v2.topHeadlines(
{
	sources: 'la-repubblica'
}).then( response =>{
	response.articles.forEach(
	    a => {
			console.log(a.title)
			console.log()
		}
	)
})

/*newsapi.v2.topHeadlines(
{
	sources: 'la-repubblica'
}).then( response =>{
	console.log(response.articles)
})*/

/*newsapi.v2.sources(
{
	language: 'it',
	country: 'it'
}).then( response =>{
	console.log(response.sources.length)
})*/


