WITH impiegati as (
SELECT 'Gino Rossi' AS nome, STRUCT("via Garibaldi 80" as indirizzo, "Roma" as citta) AS residenza, ['351998877','329727374'] AS recapiti
UNION ALL
SELECT 'Elena Bianchi' AS nome, STRUCT("piazza Cavour 100" as indirizzo, "Napoli" as citta) AS residenza, ['333372774']
UNION ALL
SELECT 'Sara Verdi' AS nome, STRUCT("corso Mazzini 200" as indirizzo, "Milano" as citta) AS residenza, ['35195577','334799994','3510687334']
)
select * from impiegati