public class EsempioVar {

	public static void main(String[] args) {
		
		 int numeroIntero=10;
		 String nome="Alessio";
		 
		 var i=10;
		 var f=1.56;
		 var logico=true;
		 
		 var var=20;
		 
		 var nomeVar="Alessio";
		 var lunghezza=nomeVar.length();
		 
		 var numeri=new int[] {12,24,36,48};
		 
		 for (var n: numeri) {
			 System.out.println(n);
		 }
	}

}
