<?php
require_once("db_config.php");

if (!array_key_exists('regione', $_GET)){
   die("Passare il parametro <strong>regione</strong> nella querystring!!");
}
$regione=$_GET['regione'];

$memcached=new Memcached();
$memcached->addServer('127.0.0.1', 11211);

$province=$memcached->get($regione);
if ($province){
   echo "[Recupero dati dalla CACHE]<br><br>";
   echo $province;
}
else{
   echo "[Recupero dati da DATABASE]<br><br>";

   $conn=new mysqli($servername, $username, $password, $dbname);
   
   if ($conn->connect_error){
      die("Database non raggiungibile: connessione fallita!");
   }
   
   $sql="SELECT province.nome as nome, sigla_automobilistica as targa 
         FROM regioni JOIN province ON regioni.id=province.id_regione
         WHERE regioni.nome='$regione';";
   $result=$conn->query($sql);
   if ($result->num_rows>0){
       while($row=$result->fetch_assoc()){
          $html.=$row["nome"]." (".$row["targa"].")<br>";
       }
       echo $html;
       $memcached->set($regione, $html);
   
   }
   else
     echo "Nessun risultato";
     
   $conn->close();
}

?>
