<?php
$servername = "172.19.0.2";
$username = "root";
$password = "topolino";
$dbname = "italia";
?>
