<!--
   Screencast
   Integrare Twitter in un'app web con PHP

   Disponibile su devACADEMY.it
-->

<!DOCTYPE html>
<html>
<head>
	<title>Twitter e PHP: esempi</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
 <?php
    require "vendor/autoload.php";
	require "twitter_cred.php";
	use Abraham\TwitterOAuth\TwitterOAuth;

	$connection=new TwitterOAuth($CONSUMER_API_KEY, $CONSUMER_API_SECRET_KEY, $ACCESS_TOKEN, $ACCESS_TOKEN_SECRET);
	$res=$connection->get("users/show", ["screen_name" => "TizianoFerro"]);
?>
<div class="w3-display-container">
	<img src="<?php echo $res->profile_banner_url?>" style="width: 100%"/>
	<div class="w3-padding w3-xlarge w3-display-bottomright w3-text-white">
	 <?php echo "$res->name (@$res->screen_name)"?> </div>
</div>
<div class="w3-padding w3-xlarge w3-grey">
    <?php echo $res->description?>
</div>
<div class="w3-container">
    <h1><?php echo "$res->followers_count followers | $res->friends_count following"?></h1>
    <h2><?php echo $res->status->text?></h2>
</div>
</body>
</html>