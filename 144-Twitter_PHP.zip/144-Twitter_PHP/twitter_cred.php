<?php

/*
 * Screencast
 * Integrare Twitter in un'app web con PHP
 *
 * Disponibile su devACADEMY.it
 */


$CONSUMER_API_KEY="";
$CONSUMER_API_SECRET_KEY="";
$ACCESS_TOKEN="";
$ACCESS_TOKEN_SECRET="";

?>