import os
from random import choice
from flask import Flask, render_template

app = Flask(__name__)
with open('proverbi.txt',encoding='utf8') as f:
    proverbi=f.readlines()

@app.route('/')
def main():
    scelto=choice(proverbi)
    return render_template('index.html', proverbio_a_caso=scelto)


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=os.environ("PORT"), debug=True)