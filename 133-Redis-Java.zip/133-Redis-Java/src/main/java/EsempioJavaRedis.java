/*
 * Screencast
 * Redis, programmazione in Java
 *
 * Disponibile su devACADEMY.it
 */


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

import redis.clients.jedis.Jedis;

class Statistiche{
	private Jedis db;

	public Statistiche(int dbnum) {
		db=new Jedis("192.168.144.3", 6379);
		db.select(dbnum);
		db.flushDB();
	}

	public void calcola(Stream<String> dati) {
		dati.forEach(s -> {
			/*
			 *  VAL-RM001 = lista dei valori per il punto vendita
			 *  NUM-RM001 = numero di transazioni del punto vendita
			 *  TOT-RM001 = totale incasso per punto vendita
			 * */
			String[] parti=s.split(",");
			db.rpush("VAL-"+parti[0], parti[1]);
			db.incr("NUM-"+parti[0]);
			db.incrByFloat("TOT-"+parti[0], Float.parseFloat(parti[1]));

		});

	}

	public void contaImportiPerPuntoVendita(String chiave /*RM001*/) {
		String res=db.get("NUM-"+chiave);
		System.out.println(res);
	}

	public void stampaConteggiPerPuntoVendita() {
		db.keys("NUM-*")
			.stream()
				.forEach(s->{
						System.out.print(s+"     ");
						System.out.println(db.get(s));
				});
	}

	public void stampaImportiPerPuntoVendita(String chiave /*RM001*/) {
		db.lrange("VAL-"+chiave, 0, -1)
			.forEach(System.out::println);
	}
}

class EsempioJavaRedis {

	private static Stream<String> leggiDati(String nomefile) throws IOException{
		return Files.readAllLines(Paths.get(nomefile))
			.stream();
	}


	public static void main(String[] args) {
			try {
				Stream<String> righe=leggiDati("incassi.csv");
				Statistiche stat=new Statistiche(2);
				stat.calcola(righe);

				//stat.contaImportiPerPuntoVendita("RM001");
				//stat.stampaConteggiPerPuntoVendita();
				stat.stampaImportiPerPuntoVendita("RM001");

			} catch (IOException e) {
				System.out.println("ERRORE ... file non trovato");
				System.exit(-1);
			}
	}
}