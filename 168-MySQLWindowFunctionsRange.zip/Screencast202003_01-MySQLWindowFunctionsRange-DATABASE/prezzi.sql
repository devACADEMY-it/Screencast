CREATE TABLE `prezzi` (
  `id` int UNSIGNED NOT NULL,
  `valore` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `prezzi` (`id`, `valore`) VALUES
(1, 22),
(2, 24),
(3, 26),
(4, 25),
(5, 28),
(6, 26),
(7, 23),
(8, 21),
(9, 19),
(10, 21),
(11, 18),
(12, 16),
(13, 19),
(14, 21),
(15, 23),
(16, 25),
(17, 20),
(18, 16),
(19, 14),
(20, 15);
