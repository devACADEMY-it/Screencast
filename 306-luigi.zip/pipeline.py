import luigi

class FirstPipeline(luigi.Task):

   def output(self):
      return luigi.LocalTarget('data.txt')

   def run(self):
      with self.output().open('w') as outf:
          from random import randint
          for i in range(1,21):
             outf.write(f'{randint(10,99)};{randint(10,99)};{randint(10,99)}\n')
