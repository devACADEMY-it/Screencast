#include<stdio.h>

int main() {
    int op1=5;
    int op2=20;
    int risultato=op1*op2;
    printf("Il risultato della moltiplicazione = %i", risultato);
}