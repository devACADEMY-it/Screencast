/*
 * Screencast
 * Classi interne in Java
 *
 * Disponibile su devACADEMY.it
 */

import java.util.ArrayList;
import java.util.List;

public class Biblioteca
{
	private List<Libro> catalogo=new ArrayList<Libro>();

	class Libro
	{
		String titolo;
		String autore;

		public void quantitaCatalogo()
		{
			System.out.println("Sono uno di "+catalogo.size()+" libri");
		}

		@Override
		public String toString() {
			return titolo+" di "+autore;
		}
	}

	void stampaLibri()
	{
		for(Libro l: catalogo)
			System.out.println(l);
	}

	Libro trovaLibroPerPosizione(int i)
	{
		return catalogo.get(i);
	}

	void aggiungi(String t, String a)
	{
		Libro l= new Libro();
		l.autore=a;
		l.titolo=t;
		catalogo.add(l);

	}

}