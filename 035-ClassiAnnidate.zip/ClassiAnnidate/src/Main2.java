/*
 * Screencast
 * Classi interne in Java
 *
 * Disponibile su devACADEMY.it
 */

class Persona
{
	String nome;

	Persona(String n)
	{
		nome=n;
	}

	@Override
	public String toString() {
		return "Mi chiamo "+nome;
	}
}

public class Main2 {

	public static void main(String[] args) {

		Persona p=new Persona("Sergio");
		System.out.println(p);

		Persona p1=new Persona("Luca")
				{
					@Override
					public String toString() {
						return super.toString()+" .... Questo � il mio nome";
					}
				};
		System.out.println(p1);

	}



}