/*
 * Screencast
 * Classi interne in Java
 *
 * Disponibile su devACADEMY.it
 */

public class Main {

	public static void main(String[] args) {

		Biblioteca b=new Biblioteca();
		b.aggiungi("Promessi sposi", "Alessandro Manzoni");
		b.aggiungi("Deserto dei Tartari", "Dino Buzzati");

		Biblioteca.Libro l=b.trovaLibroPerPosizione(0);



		Biblioteca.Libro nuovo= b.new Libro();
		nuovo.autore="Giancarlo De Cataldo";
		nuovo.titolo="Romanzo criminale";
		System.out.println(nuovo);
		System.out.println();

		l.quantitaCatalogo();

		System.out.println();

		b.stampaLibri();
	}

}