fn main(){
  for i in 1..10{
     println!("{} X {} = {}", 5, i, 5*i);
  }
  
  println!("\n altra esecuzione... \n");

  for i in 1..=10{
     println!("{} X {} = {}", 5, i, 5*i);
  }
}
