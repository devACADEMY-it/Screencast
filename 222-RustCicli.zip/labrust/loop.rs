fn main(){
   let mut conta=0;
   loop{
     println!("----> {}", conta);
     conta+=1;
     if conta==10{
        break;
     }
   }
}
