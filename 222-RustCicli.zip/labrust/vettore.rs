fn main(){
  let valori=vec![34, 5, 8, 72, 15, 12];
  for i in valori.iter(){
     if i%2==1{
        println!("{} DISPARI", i);
     }
     else
     {
        println!("{} PARI", i);
     }
  
  }
}
