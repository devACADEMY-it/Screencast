# pip install selenium
# pip install webdriver_manager

from selenium.webdriver import Chrome
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

chrome_driver=ChromeDriverManager().install()
driver = Chrome(service=Service(chrome_driver))

driver.maximize_window()

URL="http://localhost"
driver.get(URL)

elementi=driver.find_elements(By.TAG_NAME,'li')
print(f'Trovati {len(elementi)} elementi\n')

for e in elementi:
   print(e.find_element(By.TAG_NAME,'strong').text)
   
driver.quit()



