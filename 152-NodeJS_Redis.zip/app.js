/*
 * Screencast
 * Integrare Redis in Node.js
 *
 * Disponibile su devACADEMY.it
 */

var redis = require('redis')

var client = redis.createClient()

client.on('error', function(err){
	console.log('Errore: Redis non ha risposto')
})

client.on('ready', function(e){
	console.log('OK: connessione completata')
})

client.set('1M:Storia:1',8)
client.set('1M:Storia:2',7)
client.set('1M:Italiano:1',6)
client.set('1M:Italiano:2',7)
client.set('1M:Matematica:1',5)
client.set('1M:Matematica:2',6)

client.hmset('pagella', '1M:Storia:1',8, '1M:Storia:2',7,'1M:Italiano:1',6)

client.hmget('pagella', '1M:Storia:1', function(e,v){
	console.log('voto da mappa '+v)
	client.quit()
})