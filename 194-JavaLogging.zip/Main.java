import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Main {

	public static void main(String[] args) {
		FileHandler han=null;
		try {
			han=new FileHandler("log_su_file.log");
		} catch (SecurityException | IOException e) {
			// gestione delle eccezioni
		}
		SimpleFormatter formatter=new SimpleFormatter();
		han.setFormatter(formatter);
		Logger logger=Logger.getLogger(Main.class.getName());
		logger.setUseParentHandlers(false);
		logger.addHandler(han);
		System.out.println("Abbiamo stampato una riga");
		logger.log(Level.INFO, "Prima operazione eseguita");
		System.out.println("Fine programma");
		logger.info("Prima operazione eseguita");
	}

}
