from flask import Flask, request
from blockchain import BlockchainSemplice
import json

app=Flask(__name__)
blockchain=BlockchainSemplice()

@app.route('/nuova', methods=['POST'])
def nuova():
   dati=request.get_json()
   blockchain.nuova_transazione(dati)
   return "OK", 200

@app.route('/blockchain', methods=['GET'])
def download_blockchain():
   dati=[blocco.__dict__ for blocco in blockchain.blockchain]
   return json.dumps({"blockchain":dati})

@app.route('/mine', methods=['GET'])
def mine():
   blockchain.crea_blocco()
   return "OK", 200

if __name__=="__main__":
   app.run()

