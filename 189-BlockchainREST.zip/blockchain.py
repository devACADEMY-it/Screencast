import json
import time
from hashlib import sha256

class Blocco:
    def __init__(self, id, transazioni, hash_blocco_prec="0"):
        self.id=id
        self.transazioni=transazioni
        self.timestamp=time.time()
        self.hash_blocco_prec=hash_blocco_prec
        
    def calcola_hash(self):
        dati=json.dumps(self.__dict__, sort_keys=True)
        return sha256(dati.encode()).hexdigest()

class BlockchainSemplice:
    def __init__(self):
        self.storage=[]
        primo=Blocco(0, [], 0)
        primo.hash=primo.calcola_hash()
        self.blockchain=[primo]
    
    def proof_of_work(self, block):
        block.nonce=0
        hash=block.calcola_hash()
        while not hash.startswith('2'):
            print(hash)
            block.nonce+=1
            hash=block.calcola_hash()
        
        return hash
    
    def crea_blocco(self):
        ultimo=self.blockchain[-1]
        nuovo=Blocco(id=ultimo.id+1, transazioni=self.storage,hash_blocco_prec=ultimo.hash)
        proof=self.proof_of_work(nuovo)
        nuovo.hash=proof
        self.storage=[]
        self.blockchain.append(nuovo)
        
    def nuova_transazione(self, nuova):
        self.storage.append(nuova)
