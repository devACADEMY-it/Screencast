/*
 * Screencast
 * Espressioni lambda in Android
 *
 * Disponibile su devACADEMY.it
 */

package android.screencast.esempiolambda;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private int numeroClick;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn=findViewById(R.id.btn);

        btn.setOnClickListener(
                v -> {
                    Button b= (Button) v;
                    numeroClick++;
                    String messaggio="Cliccato "+numeroClick+" volte";
                    b.setText(messaggio);

                    Toast.makeText(this,
                            "Cliccato",
                            Toast.LENGTH_SHORT).show();
                }
        );

       /* btn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Button b= (Button) v;
                        numeroClick++;
                        String messaggio="Cliccato "+numeroClick+" volte";
                        b.setText(messaggio);
                        Toast.makeText(MainActivity.this,
                                        "Cliccato",
                                            Toast.LENGTH_SHORT).show();
                    }
                }
        );*/

    }
}
