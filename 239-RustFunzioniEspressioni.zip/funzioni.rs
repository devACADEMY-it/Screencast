fn stampa_saluto(){
   println!("Hello world! ... dall'interno della funzione stampa_saluto")
}

fn somma(a:u32,b:u32)->u32{
   return a+b
}

fn main(){
   let a=78;
   let b=23;

   let massimo={
       if b>a
         {b}
       else {a}
   };

   let media={
      let loro_somma=somma(a,b);
      let media=(loro_somma as f32)/2.0;
      media
   };

   stampa_saluto();

   println!("Somma di {} + {} = {}",a,b,somma(a,b));
   println!("Massimo tra {} e {} = {}",a,b,massimo);
   println!("La media di {} e {} = {}",a,b,media);
}