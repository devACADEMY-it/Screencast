fn main() {
    // dichiarazione di variabile
    let a:i8= -5;
    
    // dichiarazione di un'altra variabile
    let mut b= 6;
    
    /*
        risultato dell'operazione
    */
    println!("Risultato di {} X {} = {}", a, b, a*b);
    
    b=10;
    println!("Risultato di {} X {} = {}", a, b, a*b);
}