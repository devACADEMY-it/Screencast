#include <stdio.h>
#include <stdlib.h>
int main(){
	int cont;
	int num=5;
	printf("Di quale numero vuoi la tabellina? ");
	scanf("%d", &num);
	if (num<=0){
		printf("Il numero deve essere maggiore di 0. Impossibile procedere!");
		exit(1);
	}
	for (cont=1; cont<=10; cont++){
	   printf("%d X %d = %d \n", num, cont, num*cont);
	}
}