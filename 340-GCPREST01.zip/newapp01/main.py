import flask

app=flask.Flask(__name__)

@app.get("/")
def ciao():
    return "Buongiorno a tutti!"

if __name__=="__main__":
    app.run()
