public class TextBlocks {
    
    public static void main(String args[]){
        
        String html="""
                     <html>
                       <body>
                         <h1>Titolo della pagina</h1>
                       </body>
                     </html>
                     """;
        
        String nome="Sandra";
        
        String json="""
                    {
                        "nome": "***VARIABILE***",
                        "cognome": "Rossi",
                        "eta": 25
                    }
                    """.replace("***VARIABILE***", nome);
        
        String testo= """
                      Questa è una frase \
                      intera che per \
                      comodità spezziamo su più \
                      righe
                      """;
        
        System.out.println(html);
        System.out.println(json);
        System.out.println(testo);
    }
    
}