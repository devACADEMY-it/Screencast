/*
 * Screencast 
 * Android: gestire ListView in Kotlin
 *
 * Disponibile su devACADEMY.it
 */

package it.devacademy.tabellineinkotlin

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.TextInputEditText
import android.support.v7.app.AlertDialog
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView

class MainActivity : AppCompatActivity() {

    var listview:ListView?=null
    var adapter:ArrayAdapter<String>?=null
    var tabellinaDel=4

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listview=findViewById(R.id.listview)
        adapter=ArrayAdapter<String>(this, R.layout.row)

        listview?.adapter=adapter

        // aggiornamento tabellina
        aggiornaTabella(tabellinaDel)
    }

    private fun aggiornaTabella(numero:Int)
    {
        adapter?.clear()
        for(i in 1..10)
            adapter?.add("$numero X $i = ${i*numero}")
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when(item?.itemId){
            R.id.ricalcola -> {
                // apertura della finestra di dialogo
                ricalcolaDialog()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    fun ricalcolaDialog(){
        val builder=AlertDialog.Builder(this, R.style.AlertDialogStyle)
        builder.setTitle("Aggiornamento tabellina")

        val view=layoutInflater.inflate(R.layout.dialog, null)
        val tabellinaEditText=view.findViewById<TextInputEditText>(R.id.tabellinaEditText) as EditText

        builder.setView(view)

        builder.setPositiveButton("fatto"){
            dialog, pulsante ->
             val valore=tabellinaEditText.text
             if (valore.length>0)
                aggiornaTabella(valore.toString().toInt())
        }

        builder.show()
    }


}
