import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestDB {

	public static void main(String[] args) {
		String urldb="jdbc:h2:mem:test";
		try {
			Connection connection=DriverManager.getConnection(urldb);
			String com1="CREATE TABLE libri"
					+ "(id INT PRIMARY KEY,"
					+ "titolo VARCHAR(50),"
					+ "autore VARCHAR(100))";
			Statement statement=connection.createStatement();
			statement.execute(com1);
			
			String com2="INSERT INTO libri (id, titolo, autore) VALUES"
					+ "(1, 'Il giardino', 'Ivo Rossi'),"
					+ "(2, 'Il mio gatto', 'Sara Neri')";
			
			int righe=statement.executeUpdate(com2);
			
			System.out.println("Aggiunte "+righe+" righe alla tabella");
			
			ResultSet rs=statement.executeQuery("SELECT * FROM libri");
			while(rs.next()) {
				System.out.print("\"");
				System.out.print(rs.getString("titolo"));
				System.out.print("\" scritto da ");
				System.out.println(rs.getString("autore"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
