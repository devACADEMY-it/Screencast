public class Main {

	static int calcola_fattoriale(int da_calcolare) {
		if (da_calcolare<=2)
			return da_calcolare;
		return da_calcolare*calcola_fattoriale(da_calcolare-1);
	}
	
	public static void main(String[] args) {
		// 5! = 5*4*3*2
		int fattoriale=1;
		int da_calcolare=5;
		
		/*for (int i=2; i<=da_calcolare; i++) {
			fattoriale=fattoriale*i;
		}
		System.out.println(da_calcolare+"! = "+fattoriale);*/
		
		System.out.println(da_calcolare+"! = "+calcola_fattoriale(da_calcolare));
	}

}