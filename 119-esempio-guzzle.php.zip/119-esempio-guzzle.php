<!--

	Screencast
	PHP: Guzzle libreria client per HTTP

	Disponibile su devACADEMY.it

-->

<?php
	require_once 'vendor/autoload.php';
	use GuzzleHttp\Client;

	$client = new Client(['base_uri' => 'http://restcountries.eu/rest/v2/']);

	$response = $client->get('region/europe');

	$data = $response->getBody();

	$data = json_decode($data, true);

	//print_r($data[10]['borders'])

?>

<!DOCTYPE html>

<html>
<head>
<meta charset="UTF-8">
<title>Esempio Guzzle</title>
<style>
img{
	max-width: 85px;
	height: auto
}

span{
	padding-left: 10px;
}
</style>
</head>
<body>
 <table>
 <?php foreach ($data as $p){?>
	 <tr>
	 <td><img src="<?php echo $p['flag']?>"</td>
	 <td><span><?php echo $p['name']?></span></td>
	 </tr>
 <?php } ?>
 </table>
</body>
</html>